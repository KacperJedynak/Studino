// firebase.js
import { getApp } from '@react-native-firebase/app';
import { getAuth } from '@react-native-firebase/auth';
import { getFirestore } from '@react-native-firebase/firestore';

// Pobieramy domyślną, natywną instancję aplikacji
const app = getApp();

// Inicjalizujemy modularnie auth i firestore
export const auth = getAuth(app);
export const db = getFirestore(app);

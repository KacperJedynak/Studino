import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  ActivityIndicator,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import {
  getFirestore,
  doc,
  onSnapshot,
} from '@react-native-firebase/firestore';
import { useRoute, useNavigation } from '@react-navigation/native';

const avatarImages = {
  avatar1: require('../images/avatars/avatar1.png'),
  avatar2: require('../images/avatars/avatar2.png'),
  avatar3: require('../images/avatars/avatar3.png'),
  avatar4: require('../images/avatars/avatar4.png'),
  avatar5: require('../images/avatars/avatar5.png'),
  avatar6: require('../images/avatars/avatar6.png'),
  avatar7: require('../images/avatars/avatar7.png'),
  avatar8: require('../images/avatars/avatar8.png'),
  avatar9: require('../images/avatars/avatar9.png'),
  avatar10: require('../images/avatars/avatar10.png'),
  avatar11: require('../images/avatars/avatar11.png'),
  avatar12: require('../images/avatars/avatar12.png'),
};

export default function PublicProfileScreen() {
  const navigation = useNavigation();
  const { uid } = useRoute().params;
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const db = getFirestore();
    const userDocRef = doc(db, 'users', uid);

    const unsub = onSnapshot(
      userDocRef,
      docSnapshot => {
        if (!docSnapshot.exists()) {
          setProfile(null);
        } else {
          const d = docSnapshot.data();
          setProfile({
            avatar: d.avatar,
            username: d.username,
            createdAt: d.createdAt,
            lastLoginAt: d.lastLoginAt,
            currentStreak: d.currentStreak ?? 0,
            longestStreak: d.longestStreak ?? 0,
            currentTitle: d.currentTitle || 'Brak wybranego tytułu',
            quizzesCreated: d.quizzesCreated ?? 0,
            quizzesPlayed: d.quizzesPlayed ?? 0,
            totalPercentage: d.totalPercentage ?? 0,
            totalQuizTime: d.totalQuizTime ?? 0,
            totalQuestionsAnswered: d.totalQuestionsAnswered ?? 1,
            minigameEnglishPercent: (
              (d.englishFlashcardsCorrect / d.englishFlashcardsAnswered) *
              100
            ).toFixed(1),
            minigameMathPercent: (
              (d.mathCorrect / d.mathAnswered) *
              100
            ).toFixed(1),
            minigameChemistryPercent: (
              (d.chemistryCorrect / d.chemistryAnswered) *
              100
            ).toFixed(1),
          });
        }
        setLoading(false);
      },
      error => {
        console.error('Snapshot error:', error);
        setLoading(false);
        setProfile(null);
      },
    );

    return () => unsub();
  }, [uid]);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator color="#6495ED" size="large" />
      </View>
    );
  }
  if (!profile) {
    return <Text style={styles.errorText}>Nie znaleziono użytkownika</Text>;
  }

  const avgQuizPercent =
    profile.quizzesPlayed > 0
      ? Math.round(profile.totalPercentage / profile.quizzesPlayed)
      : 0;
  const avgTimePerQ =
    profile.totalQuizTime > 0
      ? ((profile.totalQuizTime / profile.totalQuestionsAnswered) * 60).toFixed(
          2,
        )
      : '0.00';

  const formatDate = ts => {
    if (!ts?.toDate) return '—';
    const d = ts.toDate();
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <TouchableOpacity
        style={styles.backButton}
        onPress={() => navigation.goBack()}
      >
        <Text style={styles.backArrow}>← Powrót</Text>
      </TouchableOpacity>

      <Image
        source={avatarImages[profile.avatar] || avatarImages.avatar1}
        style={styles.avatar}
      />
      <Text style={styles.username}>@{profile.username}</Text>

      <Text style={styles.titleText}>{profile.currentTitle}</Text>

      <Stat
        label="Data utworzenia konta"
        value={formatDate(profile.createdAt)}
      />
      <Stat label="Ostatnio online" value={formatDate(profile.lastLoginAt)} />
      <Stat label="Aktualna seria" value={`${profile.currentStreak}`} />
      <Stat label="Najdłuższa seria" value={`${profile.longestStreak}`} />
      <Stat label="Utworzone quizy" value={`${profile.quizzesCreated}`} />
      <Stat label="Rozegrane quizy" value={`${profile.quizzesPlayed}`} />
      <Stat label="Średni wynik quizów" value={`${avgQuizPercent}%`} />
      <Stat
        label="Całkowity czas w quizach"
        value={`${(profile.totalQuizTime / 60).toFixed(1)}h`}
      />
      <Stat label="Śr. czas na pytanie w quizach" value={`${avgTimePerQ}s`} />
      <Stat
        label="Minigra Angielski"
        value={`${
          isNaN(profile.minigameEnglishPercent)
            ? 0
            : profile.minigameEnglishPercent
        }%`}
      />
      <Stat
        label="Minigra Matematyka"
        value={`${
          isNaN(profile.minigameMathPercent) ? 0 : profile.minigameMathPercent
        }%`}
      />
      <Stat
        label="Minigra Chemia"
        value={`${
          isNaN(profile.minigameChemistryPercent)
            ? 0
            : profile.minigameChemistryPercent
        }%`}
      />
    </ScrollView>
  );
}

function Stat({ label, value }) {
  return (
    <View style={styles.statBox}>
      <Text style={styles.statLabel}>{label}</Text>
      <Text style={styles.statValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#202020',
    paddingTop: 60,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  backButton: {
    position: 'absolute',
    top: 20,
    left: 20,
  },
  backArrow: {
    color: '#6495ED',
    fontSize: 16,
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginVertical: 20,
    borderWidth: 2,
    borderColor: '#6495ED',
  },
  username: {
    fontSize: 20,
    color: '#6495ED',
    fontWeight: 'bold',
    marginBottom: 20,
  },
  statBox: {
    width: '100%',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statLabel: {
    color: '#CCC',
    fontSize: 16,
  },
  statValue: {
    color: '#FFF',
    fontWeight: 'bold',
    fontSize: 16,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#202020',
  },
  titleText: {
    fontSize: 16,
    color: '#FFF',
    marginBottom: 20,
    fontStyle: 'italic',
  },
  errorText: {
    color: '#FFF',
    padding: 20,
    fontSize: 16,
    textAlign: 'center',
  },
});

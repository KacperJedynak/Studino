import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  ImageBackground,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';

import { getApp } from '@react-native-firebase/app';
import {
  getFirestore,
  collection,
  query,
  where,
  onSnapshot,
  doc,
  deleteDoc,
} from '@react-native-firebase/firestore';

const subjectImages = {
  'Język polski': require('../images/subject_images/JezykPolski.png'),
  Matematyka: require('../images/subject_images/Matematyka.png'),
  'Język angielski': require('../images/subject_images/JezykAngielski.png'),
  'Język niemiecki': require('../images/subject_images/JezykNiemiecki.png'),
  'Język francuski': require('../images/subject_images/JezykFrancuski.png'),
  'Język hiszpański': require('../images/subject_images/JezykHiszpanski.png'),
  'Język rosyjski': require('../images/subject_images/JezykRosyjski.png'),
  'Język włoski': require('../images/subject_images/JezykWloski.png'),
  'Inny język': require('../images/subject_images/InneJezyki.png'),
  Informatyka: require('../images/subject_images/Informatyka.png'),
  Plastyka: require('../images/subject_images/Plastyka.png'),
  Muzyka: require('../images/subject_images/Muzyka.png'),
  WF: require('../images/subject_images/WF.png'),
  Religia: require('../images/subject_images/Religia.png'),
  Etyka: require('../images/subject_images/Etyka.png'),
  Historia: require('../images/subject_images/Historia.png'),
  Przyroda: require('../images/subject_images/Przyroda.png'),
  Biologia: require('../images/subject_images/Biologia.png'),
  Chemia: require('../images/subject_images/Chemia.png'),
  Fizyka: require('../images/subject_images/Fizyka.png'),
  Geografia: require('../images/subject_images/Geografia.png'),
  Technika: require('../images/subject_images/Technika.png'),
  'Wiedza o społeczeństwie': require('../images/subject_images/WOS.png'),
  'Edukacja dla bezpieczeństwa': require('../images/subject_images/EDB.png'),
  'Bezpieczeństwo i higiena pracy': require('../images/subject_images/BHP.png'),
  'Podstawy przedsiębiorczości': require('../images/subject_images/PodstawyPrzedsiebiorczosci.png'),
  'Historia sztuki': require('../images/subject_images/HistoriaSztuki.png'),
  Filozofia: require('../images/subject_images/Filozofia.png'),
  Inne: require('../images/subject_images/Inne.png'),
};

const getDifficultyStyle = diff => {
  switch (diff) {
    case 'Łatwy':
      return { color: '#4CAF50', backgroundColor: '#4CAF5020' };
    case 'Średni':
      return { color: '#FF9800', backgroundColor: '#FF980020' };
    case 'Trudny':
      return { color: '#F44336', backgroundColor: '#F4433620' };
    default:
      return { color: '#ccc', backgroundColor: '#444' };
  }
};

const getLevelStyle = lvl =>
  lvl === 'Podstawowy'
    ? { color: '#2196F3', backgroundColor: '#2196F320' }
    : { color: '#9C27B0', backgroundColor: '#9C27B020' };

export default function ManageQuizzesScreen({ route, userUid }) {
  const navigation = useNavigation();

  const userId = route?.params?.userUid || userUid;

  const [quizzes, setQuizzes] = useState([]);
  const [loading, setLoading] = useState(true);

  const db = getFirestore(getApp());

  useEffect(() => {
    if (!userId) {
      Alert.alert('Błąd', 'Brak identyfikatora użytkownika');
      setLoading(false);
      return;
    }

    const q = query(
      collection(db, 'quizzes'),
      where('created_by', '==', userId),
    );

    const unsub = onSnapshot(
      q,
      snapshot => {
        const list = snapshot.docs.map(docSnap => ({
          id: docSnap.id,
          ...docSnap.data(),
        }));
        list.sort(
          (a, b) =>
            (b.created_at?.toMillis?.() || 0) -
            (a.created_at?.toMillis?.() || 0),
        );
        setQuizzes(list);
        setLoading(false);
      },
      error => {
        console.error('Error fetching quizzes:', error);
        Alert.alert('Błąd', 'Nie udało się pobrać Twoich quizów.');
        setLoading(false);
      },
    );
    return () => unsub();
  }, [db, userId]);

  const confirmDelete = quizId => {
    Alert.alert(
      'Usuń quiz',
      'Czy na pewno chcesz usunąć ten quiz? Tej operacji nie można cofnąć.',
      [
        { text: 'Anuluj', style: 'cancel' },
        {
          text: 'Usuń',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteDoc(doc(db, 'quizzes', quizId));
            } catch (error) {
              console.error('Error deleting quiz:', error);
              Alert.alert('Błąd', 'Nie udało się usunąć quizu.');
            }
          },
        },
      ],
    );
  };

  const renderItem = ({ item }) => {
    const qCount = item.questions?.length || 0;
    const likes = item.likes || 0;
    const plays = item.playsCount || 0;
    const bgImage = subjectImages[item.subject] || null;
    const diffStyle = getDifficultyStyle(item.difficulty);
    const lvlStyle = getLevelStyle(item.level);

    return (
      <View style={styles.cardWrapper}>
        <ImageBackground
          source={bgImage}
          style={styles.bgImage}
          imageStyle={{ opacity: 0.08 }}
        >
          <View style={styles.card}>
            <View style={styles.info}>
              <Text style={styles.title} numberOfLines={1}>
                {item.title}
              </Text>
              <View style={styles.badgesRow}>
                <View style={styles.subjectBadge}>
                  <Text style={styles.subjectText}>{item.subject}</Text>
                </View>
                <View style={[styles.levelBadge, lvlStyle]}>
                  <Text style={[styles.levelText, { color: lvlStyle.color }]}>
                    {item.level}
                  </Text>
                </View>
                <View style={[styles.difficultyBadge, diffStyle]}>
                  <Text
                    style={[styles.difficultyText, { color: diffStyle.color }]}
                  >
                    {item.difficulty}
                  </Text>
                </View>
              </View>
              <View style={styles.statsRow}>
                <Text style={styles.statText}>Pytania: {qCount}</Text>
                <Text style={styles.statText}>Polubień: {likes}</Text>
                <Text style={styles.statText}>Rozegrane: {plays}</Text>
              </View>
            </View>
            <View style={styles.actions}>
              <TouchableOpacity
                style={[styles.btn, styles.editBtn]}
                onPress={() =>
                  navigation.navigate('CreateQuizScreen', { quizToEdit: item })
                }
              >
                <Text style={styles.btnText}>Edytuj</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.btn, styles.deleteBtn]}
                onPress={() => confirmDelete(item.id)}
              >
                <Text style={styles.btnText}>Usuń</Text>
              </TouchableOpacity>
            </View>
          </View>
        </ImageBackground>
      </View>
    );
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#6495ED" />
        <Text style={styles.loadingText}>Ładowanie Twoich quizów...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={styles.backButton}
        onPress={() => navigation.goBack()}
      >
        <Text style={styles.backArrow}>← Powrót</Text>
      </TouchableOpacity>

      {quizzes.length === 0 ? (
        <View style={styles.emptyWrapper}>
          <Text style={styles.emptyText}>Nie masz jeszcze żadnych quizów.</Text>
        </View>
      ) : (
        <FlatList
          data={quizzes}
          keyExtractor={q => q.id}
          renderItem={renderItem}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1a1a1a', paddingTop: 60 },
  backButton: { position: 'absolute', top: 20, left: 12, zIndex: 1 },
  backArrow: { color: '#6495ED', fontSize: 16, fontWeight: '600' },

  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { marginTop: 12, color: '#ccc', fontSize: 16 },

  emptyWrapper: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  emptyText: { color: '#555', fontSize: 18 },

  list: { padding: 12 },

  cardWrapper: {
    marginBottom: 12,
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 4,
    backgroundColor: '#2a2a2a',
  },
  bgImage: { width: '100%' },

  card: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    padding: 16,
    minHeight: 100,
  },
  info: {
    flex: 1,
    paddingRight: 16,
    maxWidth: '70%',
  },

  title: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },

  badgesRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    flexWrap: 'wrap',
  },
  subjectBadge: {
    backgroundColor: '#FFEB3B20',
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 10,
    marginRight: 6,
    marginBottom: 4,
  },
  subjectText: { color: '#FBC02D', fontWeight: '600', fontSize: 11 },

  levelBadge: {
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 10,
    marginRight: 6,
    marginBottom: 4,
  },
  levelText: { fontWeight: '600', fontSize: 11 },

  difficultyBadge: {
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 10,
    marginBottom: 4,
  },
  difficultyText: { fontWeight: '600', fontSize: 11 },

  statsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  statText: {
    color: '#ccc',
    fontSize: 12,
    marginRight: 12,
    marginBottom: 2,
  },

  actions: {
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 80,
  },
  btn: {
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 8,
    marginBottom: 8,
    minWidth: 70,
    alignItems: 'center',
  },
  editBtn: { backgroundColor: '#6495ED' },
  deleteBtn: { backgroundColor: '#F44336' },
  btnText: { color: '#fff', fontWeight: '600', fontSize: 12 },
});

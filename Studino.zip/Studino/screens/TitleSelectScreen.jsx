import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  SectionList,
  SafeAreaView,
  Alert,
} from 'react-native';
import {
  getFirestore,
  doc,
  getDoc,
  updateDoc,
} from '@react-native-firebase/firestore';
import { useRoute } from '@react-navigation/native';

export default function TitleSelectScreen({ navigation, user }) {
  const route = useRoute();
  const currentRoute = route.name;

  const [userStats, setUserStats] = useState(null);
  const [sections, setSections] = useState([]);
  const [selectedTitle, setSelectedTitle] = useState(null);
  const [titlesCount, setTitlesCount] = useState(0);

  const db = getFirestore();

  useEffect(() => {
    const load = async () => {
      try {
        const userRef = doc(db, 'users', user.uid);
        const snap = await getDoc(userRef);
        if (!snap.exists()) throw new Error('Brak dokumentu');
        const data = snap.data();
        setUserStats({
          createdAt: data.createdAt,
          longestStreak: data.longestStreak || 0,
          quizzesPlayed: data.quizzesPlayed || 0,
          totalQuizTime: data.totalQuizTime || 0,
          quizzesCreated: data.quizzesCreated || 0,
        });
        setSelectedTitle(data.selectedTitle || null);
        setTitlesCount(data.titlesCount || 0);
      } catch (e) {
        console.error(e);
      }
    };
    load();
  }, [db, user.uid]);

  useEffect(() => {
    if (!userStats) return;
    const {
      createdAt,
      longestStreak,
      quizzesPlayed,
      totalQuizTime,
      quizzesCreated,
    } = userStats;

    const accountAgeDays = Math.floor(
      (Date.now() -
        (createdAt.toDate
          ? createdAt.toDate()
          : new Date(createdAt)
        ).getTime()) /
        (1000 * 60 * 60 * 24),
    );
    const timeHours = totalQuizTime / 60;

    const raw = [
      {
        title: 'Wiek konta',
        value: accountAgeDays,
        data: [
          { label: 'Nowicjusz', desc: '< 7 dni', test: v => v < 7 },
          {
            label: 'Początkujący',
            desc: '7–30 dni',
            test: v => v >= 7 && v <= 30,
          },
          {
            label: 'Doświadczony',
            desc: '1–6 miesięcy',
            test: v => v > 30 && v <= 180,
          },
          {
            label: 'Weteran',
            desc: '6–12 miesięcy',
            test: v => v > 180 && v <= 365,
          },
          { label: 'Mistrz czasu', desc: '> 12 miesięcy', test: v => v > 365 },
        ],
      },
      {
        title: 'Najdłuższa seria',
        value: longestStreak,
        data: [
          { label: 'Pierwszy krok', desc: '≥ 1 pytanie', test: v => v >= 1 },
          {
            label: 'Seria w toku',
            desc: '2–15 pytań',
            test: v => v >= 2 && v <= 15,
          },
          {
            label: 'Nieustępliwy',
            desc: '16–50 pytań',
            test: v => v >= 16 && v <= 50,
          },
          {
            label: 'Mistrz ciągłości',
            desc: '51–200 pytań',
            test: v => v >= 51 && v <= 200,
          },
          { label: 'Niepokonany', desc: '≥ 201 pytań', test: v => v >= 201 },
        ],
      },
      {
        title: 'Rozegrane quizy',
        value: quizzesPlayed,
        data: [
          { label: 'Gracz amator', desc: '1–25', test: v => v >= 1 && v <= 25 },
          {
            label: 'Entuzjasta',
            desc: '26–100',
            test: v => v >= 26 && v <= 100,
          },
          {
            label: 'Regular',
            desc: '101–250',
            test: v => v >= 101 && v <= 250,
          },
          {
            label: 'Zapalony gracz',
            desc: '251–1000',
            test: v => v >= 251 && v <= 1000,
          },
          { label: 'Arcymistrz', desc: '> 1001', test: v => v > 1001 },
        ],
      },
      {
        title: 'Czas spędzony (h)',
        value: timeHours,
        data: [
          { label: 'Szybki ptaszek', desc: '< 0.5 h', test: h => h < 0.5 },
          {
            label: 'Uczciwy gracz',
            desc: '0.5–3 h',
            test: h => h >= 0.5 && h <= 3,
          },
          {
            label: 'Godzinowy wirtuoz',
            desc: '3–20 h',
            test: h => h >= 3 && h <= 20,
          },
          {
            label: 'Marathonista',
            desc: '20–100 h',
            test: h => h >= 20 && h <= 100,
          },
          { label: 'Żywa encyklopedia', desc: '> 100 h', test: h => h > 100 },
        ],
      },
      {
        title: 'Utworzone quizy',
        value: quizzesCreated,
        data: [
          {
            label: 'Autor z pierwszej ławki',
            desc: '1–3',
            test: v => v >= 1 && v <= 3,
          },
          { label: 'Twórca', desc: '4–10', test: v => v >= 4 && v <= 10 },
          { label: 'Kreator', desc: '11–25', test: v => v >= 11 && v <= 25 },
          {
            label: 'Producent quizów',
            desc: '26–50',
            test: v => v >= 26 && v <= 50,
          },
          { label: 'Architekt wiedzy', desc: '> 50', test: v => v > 50 },
        ],
      },
    ];

    let count = 0;
    const built = raw.map(section => {
      let maxIdx = -1;
      section.data.forEach((it, idx) => {
        if (it.test(section.value)) maxIdx = idx;
      });
      count += maxIdx + 1;
      return {
        title: section.title,
        data: section.data.map((it, idx) => ({
          label: it.label,
          desc: it.desc,
          unlocked: idx <= maxIdx,
        })),
      };
    });

    setSections(built);
    setTitlesCount(count);

    const userRef = doc(db, 'users', user.uid);
    updateDoc(userRef, { titlesCount: count }).catch(console.error);
  }, [userStats, db, user.uid]);

  if (!userStats) {
    return (
      <SafeAreaView style={styles.center}>
        <Text style={styles.loading}>Ładowanie…</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.counterRow}>
        <Text style={styles.counterLabel}>Zdobyte tytuły:</Text>
        <Text style={styles.counterValue}>{titlesCount}</Text>
      </View>

      <SectionList
        sections={sections}
        keyExtractor={(item, idx) => item.label + idx}
        renderSectionHeader={({ section: { title } }) => (
          <Text style={styles.sectionHeader}>{title}</Text>
        )}
        renderItem={({ item }) => {
          const isSelected = item.label === selectedTitle;
          return (
            <TouchableOpacity
              style={[
                styles.item,
                !item.unlocked && styles.disabledItem,
                isSelected && styles.selectedItem,
              ]}
              disabled={!item.unlocked}
              onPress={() => setSelectedTitle(item.label)}
            >
              <View style={styles.itemRow}>
                <View>
                  <Text
                    style={[
                      styles.itemLabel,
                      !item.unlocked && styles.disabledText,
                    ]}
                  >
                    {item.label}
                  </Text>
                  <Text
                    style={[
                      styles.itemDesc,
                      !item.unlocked && styles.disabledText,
                    ]}
                  >
                    {item.desc}
                  </Text>
                </View>
                {isSelected && <Text style={styles.checkmark}>✓</Text>}
              </View>
            </TouchableOpacity>
          );
        }}
        contentContainerStyle={styles.listContent}
      />

      {selectedTitle && (
        <TouchableOpacity
          style={[styles.saveBtn, { marginBottom: 80 }]}
          onPress={async () => {
            try {
              const userRef = doc(db, 'users', user.uid);
              await updateDoc(userRef, { selectedTitle });
              Alert.alert('Sukces', 'Zapisano tytuł');
              navigation.goBack();
            } catch {
              Alert.alert('Błąd', 'Nie udało się zapisać tytułu');
            }
          }}
        >
          <Text style={styles.saveText}>Zapisz tytuł</Text>
        </TouchableOpacity>
      )}

      <View style={styles.bottomNavigation}>
        <TouchableOpacity
          style={[
            styles.navButton,
            currentRoute === 'HomeScreen' && styles.activeNavButton,
          ]}
          onPress={() => navigation.navigate('HomeScreen')}
        >
          <Text style={styles.navEmoji}>🏠</Text>
          <Text style={styles.navLabel}>Główna</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.navButton,
            currentRoute === 'QuizSelectScreen' && styles.activeNavButton,
          ]}
          onPress={() => navigation.navigate('QuizSelectScreen')}
        >
          <Text style={styles.navEmoji}>🎯</Text>
          <Text style={styles.navLabel}>Quizy</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.navButton,
            currentRoute === 'YourProfile' && styles.activeNavButton,
          ]}
          onPress={() => navigation.navigate('YourProfile')}
        >
          <Text style={styles.navEmoji}>👤</Text>
          <Text style={styles.navLabel}>Profil</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.navButton,
            currentRoute === 'TitleSelectScreen' && styles.activeNavButton,
          ]}
          onPress={() => navigation.navigate('TitleSelectScreen')}
        >
          <Text style={styles.navEmoji}>🏅</Text>
          <Text style={styles.navLabel}>Tytuły</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.navButton,
            currentRoute === 'Settings' && styles.activeNavButton,
          ]}
          onPress={() => navigation.navigate('Settings')}
        >
          <Text style={styles.navEmoji}>⚙️</Text>
          <Text style={styles.navLabel}>Ustawienia</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#1F1F1F', padding: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loading: { color: '#FFF' },

  counterRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 12,
    backgroundColor: '#2A2A2A',
    borderRadius: 8,
    marginBottom: 12,
  },
  counterLabel: { color: '#CCC', fontSize: 16 },
  counterValue: { color: '#4CAF50', fontSize: 16, fontWeight: '700' },

  sectionHeader: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFF',
    marginTop: 12,
    marginBottom: 6,
  },
  item: {
    backgroundColor: '#2A2A2A',
    padding: 12,
    borderRadius: 8,
    marginVertical: 4,
  },
  disabledItem: { opacity: 0.4 },
  selectedItem: { backgroundColor: '#3D4ED8' },
  itemRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  itemLabel: { color: '#FFF', fontWeight: '600' },
  itemDesc: { color: '#BBB', fontSize: 12 },
  disabledText: { color: '#555' },
  checkmark: { fontSize: 24, color: '#4CAF50' },

  saveBtn: {
    backgroundColor: '#4CAF50',
    padding: 14,
    borderRadius: 25,
    alignItems: 'center',
    marginTop: 12,
  },
  saveText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },

  listContent: { paddingBottom: 50 },

  bottomNavigation: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    backgroundColor: '#2d2d2d',
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: '#444',
  },
  navButton: { flex: 1, alignItems: 'center' },
  activeNavButton: { backgroundColor: '#333' },
  navEmoji: { fontSize: 20 },
  navLabel: { color: '#CCC', fontSize: 10, marginTop: 2 },
});

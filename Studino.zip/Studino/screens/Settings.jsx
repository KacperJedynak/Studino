import React, { useState, useEffect } from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  Keyboard,
  Alert,
  BackHandler,
} from 'react-native';

import { getApp } from '@react-native-firebase/app';
import { getAuth, EmailAuthProvider } from '@react-native-firebase/auth';
import {
  getFirestore,
  collection,
  doc,
  query,
  where,
  getDocs,
  writeBatch,
  updateDoc,
  deleteDoc,
} from '@react-native-firebase/firestore';

import { useRoute, useNavigation } from '@react-navigation/native';

const app = getApp();
const auth = getAuth(app);
const db = getFirestore(app);

export default function Settings({
  user,
  userProfile,
  onProfileUpdated,
  checkUsernameAvailability,
  onLogout,
}) {
  const navigation = useNavigation();
  const route = useRoute();
  const currentRoute = route.name;

  if (!userProfile) return null;

  const [username, setUsername] = useState(userProfile.username);
  const [newPassword, setNewPassword] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isKeyboardVisible, setKeyboardVisible] = useState(false);

  useEffect(() => {
    setUsername(userProfile.username);
  }, [userProfile.username]);

  useEffect(() => {
    const show = Keyboard.addListener('keyboardDidShow', () =>
      setKeyboardVisible(true),
    );
    const hide = Keyboard.addListener('keyboardDidHide', () =>
      setKeyboardVisible(false),
    );
    return () => {
      show.remove();
      hide.remove();
    };
  }, []);

  useEffect(() => {
    const handler = BackHandler.addEventListener('hardwareBackPress', () => {
      navigation.goBack();
      return true;
    });
    return () => handler.remove();
  }, [navigation]);

  const reauthenticate = pw => {
    const cred = EmailAuthProvider.credential(user.email, pw);
    return auth.currentUser.reauthenticateWithCredential(cred);
  };

  const firebaseErrorToMessage = code => {
    switch (code) {
      case 'auth/wrong-password':
      case 'auth/invalid-credential':
        return 'Nieprawidłowe hasło.';
      case 'auth/weak-password':
        return 'Hasło jest za słabe (min. 6 znaków).';
      case 'auth/requires-recent-login':
        return 'Wymagana ponowna autoryzacja – zaloguj się ponownie.';
      case 'firestore/permission-denied':
        return 'Brak uprawnień do wykonania tej operacji.';
      default:
        return 'Wystąpił nieznany błąd.';
    }
  };

  const handleSave = async () => {
    setErrorMessage('');
    setSuccessMessage('');

    const tName = username.trim();
    const tNewPw = newPassword.trim();
    const tCurrPw = currentPassword.trim();

    const nameChanged =
      tName.toLowerCase() !== userProfile.username.toLowerCase();
    const pwChanged = tNewPw.length > 0;

    if (!nameChanged && !pwChanged) {
      setErrorMessage('Brak zmian do zapisania.');
      return;
    }
    if ((nameChanged || pwChanged) && !tCurrPw) {
      setErrorMessage('Podaj aktualne hasło, aby zapisać zmiany.');
      return;
    }

    setLoading(true);

    try {
      await reauthenticate(tCurrPw);
    } catch (e) {
      setErrorMessage(firebaseErrorToMessage(e.code || ''));
      setLoading(false);
      return;
    }

    if (pwChanged) {
      if (tNewPw.length < 6) {
        setErrorMessage('Nowe hasło musi mieć co najmniej 6 znaków.');
        setLoading(false);
        return;
      }
      try {
        await auth.currentUser.updatePassword(tNewPw);
      } catch (e) {
        setErrorMessage(firebaseErrorToMessage(e.code || ''));
        setLoading(false);
        return;
      }
    }

    if (nameChanged) {
      if (tName.length < 3) {
        setErrorMessage('Nazwa musi mieć co najmniej 3 znaki.');
        setLoading(false);
        return;
      }
      if (tName.length > 20) {
        setErrorMessage('Nazwa nie może przekraczać 20 znaków.');
        setLoading(false);
        return;
      }
      const available = await checkUsernameAvailability(tName);
      if (!available) {
        setErrorMessage('Ta nazwa użytkownika jest już zajęta.');
        setLoading(false);
        return;
      }
      try {
        const userRef = doc(db, 'users', user.uid);
        await updateDoc(userRef, { username: tName });

        const q = query(
          collection(db, 'quizzes'),
          where('created_by', '==', user.uid),
        );
        const snap = await getDocs(q);
        if (!snap.empty) {
          const batch = writeBatch(db);
          snap.docs.forEach(quizDoc => {
            batch.update(quizDoc.ref, { created_by_name: tName });
          });
          await batch.commit();
        }
      } catch (e) {
        setErrorMessage(firebaseErrorToMessage(e.code || ''));
        setLoading(false);
        return;
      }
    }

    onProfileUpdated({ ...userProfile, username: tName });
    setSuccessMessage('Dane zostały zapisane.');
    setNewPassword('');
    setCurrentPassword('');
    setLoading(false);
  };

  const handlePasswordResetEmail = async () => {
    setErrorMessage('');
    setSuccessMessage('');
    setLoading(true);
    try {
      await auth.sendPasswordResetEmail(user.email);
      setSuccessMessage('Link resetu hasła został wysłany na Twój email.');
    } catch (e) {
      setErrorMessage(firebaseErrorToMessage(e.code || ''));
    } finally {
      setLoading(false);
    }
  };

  const confirmDelete = () => {
    Alert.alert(
      'Usuń konto',
      'Czy na pewno chcesz usunąć konto? Ta operacja jest nieodwracalna.',
      [
        { text: 'Anuluj', style: 'cancel' },
        { text: 'Usuń', style: 'destructive', onPress: handleDeleteAccount },
      ],
    );
  };

  const handleDeleteAccount = async () => {
    setErrorMessage('');
    const tCurrPw = currentPassword.trim();
    if (!tCurrPw) {
      setErrorMessage('Podaj aktualne hasło, aby usunąć konto.');
      return;
    }
    setLoading(true);
    try {
      await reauthenticate(tCurrPw);
      await deleteDoc(doc(db, 'users', user.uid));
      await auth.currentUser.delete();
    } catch (e) {
      setErrorMessage(firebaseErrorToMessage(e.code || ''));
      setLoading(false);
      return;
    }
    setLoading(false);
  };

  return (
    <View style={styles.wrapper}>
      <SafeAreaView style={{ flex: 1 }}>
        <KeyboardAvoidingView
          style={{ flex: 1 }}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
          <ScrollView contentContainerStyle={styles.container}>
            <Text style={styles.title}>Ustawienia konta</Text>

            <Text style={styles.label}>Nazwa</Text>
            <TextInput
              style={styles.input}
              value={username}
              onChangeText={setUsername}
              placeholder="Nowy nick"
              placeholderTextColor="#888"
            />

            <Text style={styles.label}>Email</Text>
            <TextInput
              style={[styles.input, styles.readonly]}
              value={user.email}
              editable={false}
            />

            <Text style={styles.label}>Nowe hasło</Text>
            <TextInput
              style={styles.input}
              value={newPassword}
              onChangeText={setNewPassword}
              placeholder="Pozostaw puste, aby nie zmieniać"
              placeholderTextColor="#888"
              secureTextEntry
            />

            <Text style={styles.label}>Aktualne hasło</Text>
            <TextInput
              style={styles.input}
              value={currentPassword}
              onChangeText={setCurrentPassword}
              placeholder="Podaj aktualne hasło"
              placeholderTextColor="#888"
              secureTextEntry
            />

            <View style={styles.buttonsRow}>
              <TouchableOpacity
                style={[styles.button, styles.cancelButton]}
                onPress={() => navigation.goBack()}
                disabled={loading}
              >
                <Text style={styles.cancelText}>Anuluj</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.button, styles.saveButton]}
                onPress={handleSave}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#FFF" />
                ) : (
                  <Text style={styles.saveText}>Zapisz</Text>
                )}
              </TouchableOpacity>
            </View>

            {!!errorMessage && (
              <Text style={styles.errorText}>{errorMessage}</Text>
            )}
            {!!successMessage && (
              <Text style={styles.successText}>{successMessage}</Text>
            )}

            <TouchableOpacity
              style={[styles.button, styles.resetButton]}
              onPress={handlePasswordResetEmail}
              disabled={loading}
            >
              <Text style={styles.resetText}>Wyślij link resetu hasła</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.button, styles.logoutButton]}
              onPress={onLogout}
              disabled={loading}
            >
              <Text style={styles.logoutText}>Wyloguj się</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.button, styles.deleteButton]}
              onPress={confirmDelete}
              disabled={loading}
            >
              <Text style={styles.deleteText}>Usuń konto</Text>
            </TouchableOpacity>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>

      {!isKeyboardVisible && (
        <View style={styles.bottomNavigation}>
          <TouchableOpacity
            style={[
              styles.navButton,
              currentRoute === 'HomeScreen' && styles.activeNavButton,
            ]}
            onPress={() => navigation.navigate('HomeScreen')}
          >
            <Text style={styles.navEmoji}>🏠</Text>
            <Text style={styles.navLabel}>Główna</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.navButton,
              currentRoute === 'QuizSelectScreen' && styles.activeNavButton,
            ]}
            onPress={() => navigation.navigate('QuizSelectScreen')}
          >
            <Text style={styles.navEmoji}>🎯</Text>
            <Text style={styles.navLabel}>Quizy</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.navButton,
              currentRoute === 'YourProfile' && styles.activeNavButton,
            ]}
            onPress={() => navigation.navigate('YourProfile')}
          >
            <Text style={styles.navEmoji}>👤</Text>
            <Text style={styles.navLabel}>Profil</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.navButton,
              currentRoute === 'TitleSelectScreen' && styles.activeNavButton,
            ]}
            onPress={() => navigation.navigate('TitleSelectScreen')}
          >
            <Text style={styles.navEmoji}>🏅</Text>
            <Text style={styles.navLabel}>Tytuły</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.navButton,
              currentRoute === 'Settings' && styles.activeNavButton,
            ]}
            onPress={() => navigation.navigate('Settings')}
          >
            <Text style={styles.navEmoji}>⚙️</Text>
            <Text style={styles.navLabel}>Ustawienia</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: { flex: 1, backgroundColor: '#202020' },
  container: { padding: 20, paddingBottom: 20 },
  title: { fontSize: 24, color: '#FFF', fontWeight: 'bold', marginBottom: 10 },
  label: { color: '#CCC', marginBottom: 5 },
  input: {
    backgroundColor: '#333',
    color: '#FFF',
    padding: 10,
    borderRadius: 8,
    marginBottom: 15,
  },
  readonly: { opacity: 0.6 },
  buttonsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  button: {
    flex: 1,
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginVertical: 8,
  },
  cancelButton: { backgroundColor: '#777', marginRight: 10 },
  cancelText: { color: '#FFF', fontWeight: 'bold' },
  saveButton: { backgroundColor: '#6495ED' },
  saveText: { color: '#FFF', fontWeight: 'bold' },
  resetButton: { backgroundColor: '#FFA000', marginBottom: 40 },
  resetText: { color: '#FFF', fontWeight: 'bold' },
  logoutButton: { backgroundColor: '#607D8B', marginBottom: 40 },
  logoutText: { color: '#FFF', fontWeight: 'bold' },
  deleteButton: { backgroundColor: '#E74C3C' },
  deleteText: { color: '#FFF', fontWeight: 'bold' },
  errorText: {
    color: '#E74C3C',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 10,
  },
  successText: {
    color: '#4CAF50',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 10,
  },
  bottomNavigation: {
    flexDirection: 'row',
    backgroundColor: '#2d2d2d',
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: '#444',
  },
  navButton: { flex: 1, alignItems: 'center', marginHorizontal: 4 },
  activeNavButton: { backgroundColor: '#333' },
  navEmoji: { fontSize: 20 },
  navLabel: { color: '#CCC', fontSize: 10, marginTop: 2 },
});

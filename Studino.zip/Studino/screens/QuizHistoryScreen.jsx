import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  ActivityIndicator,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  getFirestore,
  collection,
  query,
  where,
  orderBy,
  onSnapshot,
  doc,
  getDoc,
} from '@react-native-firebase/firestore';

export default function QuizHistoryScreen({ navigation, user }) {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const userId = user.uid;

  useEffect(() => {
    const db = getFirestore();
    const q = query(
      collection(db, 'quiz_results'),
      where('userId', '==', userId),
      orderBy('completedAt', 'desc'),
    );

    const unsubscribe = onSnapshot(
      q,
      async snapshot => {
        try {
          const docs = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data(),
          }));

          const enrichedHistory = await Promise.all(
            docs.map(async result => {
              try {
                const quizRef = doc(getFirestore(), 'quizzes', result.quizId);
                const quizSnap = await getDoc(quizRef);
                const quizData = quizSnap.exists() ? quizSnap.data() : {};

                return {
                  ...result,
                  quizTitle: quizData.title || 'Nieznany Quiz',
                  quizDescription: quizData.description || '',
                };
              } catch (error) {
                console.error('Error fetching quiz data:', error);
                return {
                  ...result,
                  quizTitle: 'Nieznany Quiz',
                  quizDescription: '',
                };
              }
            }),
          );

          setHistory(enrichedHistory);
        } catch (error) {
          console.error('Error processing quiz history:', error);
          setHistory([]);
        } finally {
          setLoading(false);
        }
      },
      error => {
        console.error('QuizHistory onSnapshot error:', error);
        setLoading(false);
        Alert.alert('Błąd', 'Nie udało się załadować historii quizów');
      },
    );

    return unsubscribe;
  }, [userId]);

  const formatTime = ms => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return minutes > 0
      ? `${minutes}m ${remainingSeconds}s`
      : `${remainingSeconds}s`;
  };

  const formatDate = timestamp => {
    const date = new Date(timestamp);
    return date.toLocaleDateString('pl-PL', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getPerformanceColor = percentage => {
    if (percentage >= 90) return '#4CAF50';
    if (percentage >= 70) return '#FF9800';
    if (percentage >= 50) return '#FFC107';
    return '#f44336';
  };

  const getPerformanceEmoji = percentage => {
    if (percentage >= 90) return '🎉';
    if (percentage >= 70) return '👏';
    if (percentage >= 50) return '👍';
    return '💪';
  };

  const handleItemPress = item => {
    const resultsData = {
      quiz: {
        id: item.quizId,
        title: item.quizTitle,
        description: item.quizDescription,
      },
      answers: item.answers || [],
      correctAnswers: item.correctAnswers,
      totalQuestions: item.totalQuestions,
      percentage: Math.round(item.percentage),
      totalTime: item.totalTime,
      completedAt: item.completedAt,
    };

    navigation.navigate('QuizResultsScreen', {
      results: resultsData,
      quiz: resultsData.quiz,
      userId: user.uid,
      fromHistory: true,
    });
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.center}>
          <ActivityIndicator size="large" color="#6495ED" />
          <Text style={styles.loadingText}>Ładowanie historii...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (history.length === 0) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.center}>
          <Text style={styles.emptyText}>📚 Brak historii quizów</Text>
          <Text style={styles.emptySubtext}>
            Rozwiąż pierwszy quiz, aby zobaczyć swoją historię!
          </Text>
          <TouchableOpacity
            style={styles.browseButton}
            onPress={() => navigation.navigate('BrowseQuizesScreen')}
          >
            <Text style={styles.browseButtonText}>Przeglądaj Quizy</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.item}
      onPress={() => handleItemPress(item)}
      activeOpacity={0.8}
    >
      <View style={styles.headerRow}>
        <Text style={styles.title} numberOfLines={2}>
          {item.quizTitle}
        </Text>
        <View style={styles.scoreContainer}>
          <Text
            style={[
              styles.percentage,
              { color: getPerformanceColor(item.percentage) },
            ]}
          >
            {Math.round(item.percentage)}%
          </Text>
          <Text style={styles.emoji}>
            {getPerformanceEmoji(item.percentage)}
          </Text>
        </View>
      </View>

      <View style={styles.statsRow}>
        <Text style={styles.stat}>
          ✅ {item.correctAnswers}/{item.totalQuestions}
        </Text>
        <Text style={styles.stat}>⏱️ {formatTime(item.totalTime)}</Text>
      </View>

      <Text style={styles.date}>📅 {formatDate(item.completedAt)}</Text>

      <View style={styles.viewDetailsContainer}>
        <Text style={styles.viewDetailsText}>
          Dotknij, aby zobaczyć szczegóły →
        </Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.backRow}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.backArrow}>← Powrót</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Historia Quizów</Text>
        <Text style={styles.headerSubtitle}>
          Rozwiązane quizy: {history.length}
        </Text>
      </View>

      <FlatList
        data={history}
        keyExtractor={item => item.id}
        renderItem={renderItem}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#202020',
  },
  backRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  backArrow: {
    color: '#6495ED',
    fontSize: 16,
    marginRight: 12,
  },
  header: {
    padding: 20,
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  headerTitle: {
    color: '#FFF',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  headerSubtitle: {
    color: '#888',
    fontSize: 14,
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  loadingText: {
    color: '#CCC',
    fontSize: 16,
    marginTop: 10,
  },
  list: {
    padding: 16,
    paddingTop: 8,
  },
  emptyText: {
    color: '#CCC',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
  },
  emptySubtext: {
    color: '#888',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 20,
  },
  browseButton: {
    backgroundColor: '#6495ED',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
  },
  browseButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  item: {
    backgroundColor: '#2B2B2B',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#6495ED',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  title: {
    color: '#6495ED',
    fontSize: 16,
    fontWeight: 'bold',
    flex: 1,
    marginRight: 10,
  },
  scoreContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  percentage: {
    fontSize: 18,
    fontWeight: 'bold',
    marginRight: 4,
  },
  emoji: {
    fontSize: 16,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  stat: {
    color: '#CCC',
    fontSize: 14,
  },
  date: {
    color: '#888',
    fontSize: 12,
    marginBottom: 8,
  },
  viewDetailsContainer: {
    alignItems: 'flex-end',
  },
  viewDetailsText: {
    color: '#6495ED',
    fontSize: 12,
    fontStyle: 'italic',
  },
});

import React, { useState, useCallback, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  SafeAreaView,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from 'react-native';

import { getApp } from '@react-native-firebase/app';
import { getAuth } from '@react-native-firebase/auth';
import {
  getFirestore,
  doc,
  updateDoc,
  increment,
} from '@react-native-firebase/firestore';

import { useNavigation } from '@react-navigation/native';

import WORDS_DATA from '../jsons/EnglishWords.json';

const app = getApp();
const auth = getAuth(app);
const db = getFirestore(app);

export default function EnglishMinigameScreen({ route }) {
  const navigation = useNavigation();
  const { direction } = route.params;
  const [words, setWords] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [question, setQuestion] = useState(null);
  const [answer, setAnswer] = useState('');
  const [feedback, setFeedback] = useState(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [showUnansweredWarning, setShowUnansweredWarning] = useState(false);

  useEffect(() => {
    try {
      setWords(WORDS_DATA);
      setQuestion(getRandomWord(WORDS_DATA));
      setIsLoading(false);
    } catch (error) {
      console.error('Błąd ładowania słów:', error);
      setIsLoading(false);
    }
  }, []);

  function getRandomWord(wordsArray) {
    if (!wordsArray || wordsArray.length === 0) return null;
    return wordsArray[Math.floor(Math.random() * wordsArray.length)];
  }

  const nextQuestion = useCallback(() => {
    if (words.length === 0) return;
    let next = getRandomWord(words);
    let attempts = 0;
    while (
      next &&
      question &&
      next.eng === question.eng &&
      JSON.stringify(next.pl) === JSON.stringify(question.pl) &&
      attempts < 10
    ) {
      next = getRandomWord(words);
      attempts++;
    }
    setQuestion(next);
    setAnswer('');
    setFeedback(null);
    setIsAnswered(false);
    setShowUnansweredWarning(false);
  }, [question, words]);

  const handleCheck = async () => {
    if (!answer.trim()) {
      setFeedback('empty');
      return;
    }
    if (!question) return;

    const correctList =
      direction === 'eng2pl'
        ? question.pl.map(w => w.toLowerCase().trim())
        : [question.eng.toLowerCase().trim()];
    const isCorrect = correctList.includes(answer.toLowerCase().trim());

    setFeedback(isCorrect ? 'correct' : 'wrong');
    setIsAnswered(true);
    setShowUnansweredWarning(false);

    try {
      const uid = auth.currentUser.uid;
      const userRef = doc(db, 'users', uid);
      await updateDoc(userRef, {
        englishFlashcardsAnswered: increment(1),
        englishFlashcardsCorrect: increment(isCorrect ? 1 : 0),
      });
    } catch (e) {
      console.warn('Błąd aktualizacji statystyk:', e);
    }
  };

  const handleNextPress = () => {
    if (!isAnswered) {
      setShowUnansweredWarning(true);
      return;
    }
    nextQuestion();
  };

  const promptText = question
    ? direction === 'eng2pl'
      ? question.eng
      : question.pl[0]
    : '';

  let feedbackText = '';
  if (feedback === 'correct') {
    feedbackText = '✔️ Poprawnie!';
  } else if (feedback === 'wrong' && question) {
    const correct =
      direction === 'eng2pl' ? question.pl.join(', ') : question.eng;
    feedbackText = `❌ Poprawnie: ${correct}`;
  } else if (feedback === 'empty') {
    feedbackText = '❗ Proszę wpisać odpowiedź.';
  }

  const unansweredWarningText = showUnansweredWarning
    ? '❗ Najpierw odpowiedz na pytanie.'
    : '';

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text style={styles.loadingText}>Ładowanie słów...</Text>
      </SafeAreaView>
    );
  }

  if (!question) {
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.errorText}>Błąd ładowania słów</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <TouchableOpacity
        style={styles.backButton}
        onPress={() => navigation.goBack()}
      >
        <Text style={styles.backArrow}>← Powrót</Text>
      </TouchableOpacity>

      <Text style={styles.prompt}>{promptText}</Text>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={styles.inputWrapper}
      >
        <TextInput
          style={styles.input}
          value={answer}
          onChangeText={text => {
            setAnswer(text);
            if (feedback !== null) setFeedback(null);
            if (showUnansweredWarning) setShowUnansweredWarning(false);
          }}
          placeholder="Wpisz odpowiedź"
          placeholderTextColor="#AAA"
          autoCapitalize="none"
          returnKeyType="done"
          onSubmitEditing={handleCheck}
        />
        <TouchableOpacity
          style={[styles.checkBtn, isAnswered && styles.checkBtnDisabled]}
          onPress={handleCheck}
          disabled={isAnswered}
        >
          <Text
            style={[styles.checkTxt, isAnswered && styles.checkTxtDisabled]}
          >
            {isAnswered ? 'Sprawdzone' : 'Sprawdź'}
          </Text>
        </TouchableOpacity>
      </KeyboardAvoidingView>

      {(feedback !== null || showUnansweredWarning) && (
        <Text
          style={[
            styles.feedback,
            feedback === 'correct' && styles.feedbackCorrect,
            feedback === 'wrong' && styles.feedbackWrong,
            (feedback === 'empty' || showUnansweredWarning) &&
              styles.feedbackWarning,
          ]}
        >
          {feedbackText || unansweredWarningText}
        </Text>
      )}

      <TouchableOpacity style={styles.nextBtn} onPress={handleNextPress}>
        <Text style={styles.nextTxt}>Następne słowo</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#2C2C2E',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    paddingTop: Platform.OS === 'android' ? 60 : 20,
  },
  backButton: {
    position: 'absolute',
    top: Platform.OS === 'android' ? 20 : 10,
    left: 20,
    zIndex: 1,
  },
  backArrow: {
    color: '#007AFF',
    fontSize: 16,
    fontWeight: '600',
  },
  prompt: {
    color: '#FFFFFF',
    fontSize: 36,
    fontWeight: '700',
    marginBottom: 30,
    textAlign: 'center',
    letterSpacing: 1,
  },
  inputWrapper: {
    width: '85%',
    alignItems: 'center',
    marginBottom: 20,
  },
  input: {
    width: '100%',
    borderWidth: 2,
    borderColor: '#48484A',
    borderRadius: 12,
    padding: 16,
    fontSize: 20,
    color: '#FFFFFF',
    backgroundColor: '#1C1C1E',
    marginBottom: 16,
    textAlign: 'center',
    fontWeight: '500',
  },
  checkBtn: {
    backgroundColor: '#34C759',
    paddingVertical: 14,
    paddingHorizontal: 40,
    borderRadius: 12,
    elevation: 5,
  },
  checkBtnDisabled: {
    backgroundColor: '#48484A',
    elevation: 0,
  },
  checkTxt: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '700',
    textAlign: 'center',
  },
  checkTxtDisabled: {
    color: '#8E8E93',
  },
  feedback: {
    fontSize: 18,
    marginTop: 25,
    marginBottom: 10,
    textAlign: 'center',
    fontWeight: '600',
    paddingHorizontal: 20,
  },
  feedbackCorrect: {
    color: '#34C759',
  },
  feedbackWrong: {
    color: '#FF3B30',
  },
  feedbackWarning: {
    color: '#FF9500',
  },
  nextBtn: {
    marginTop: 20,
    backgroundColor: '#007AFF',
    paddingVertical: 14,
    paddingHorizontal: 40,
    borderRadius: 12,
    elevation: 5,
  },
  nextTxt: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '700',
    textAlign: 'center',
  },
  loadingText: {
    color: '#FFFFFF',
    fontSize: 18,
    marginTop: 20,
    textAlign: 'center',
  },
  errorText: {
    color: '#FF3B30',
    fontSize: 18,
    textAlign: 'center',
    fontWeight: '600',
  },
});

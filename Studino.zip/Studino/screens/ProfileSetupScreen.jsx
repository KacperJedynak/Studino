import React, { useState } from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Image,
  Alert,
  ActivityIndicator,
} from 'react-native';
import {
  getFirestore,
  doc,
  setDoc,
  serverTimestamp,
} from '@react-native-firebase/firestore';

const ProfileSetupScreen = ({
  user,
  avatarImages,
  checkUsernameAvailability,
  onProfileCreated,
}) => {
  const [username, setUsername] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState('avatar1');
  const [loading, setLoading] = useState(false);

  const handleProfileSetup = async () => {
    const trimmed = username.trim();

    if (trimmed.length < 3 || trimmed.length > 20) {
      return Alert.alert('Błąd', 'Nazwa musi mieć 3–20 znaków');
    }
    if (!/^[A-Za-z0-9._-]+$/.test(trimmed)) {
      return Alert.alert(
        'Błąd',
        'Tylko litery, cyfry, kropki, myślniki i podkreślniki',
      );
    }

    setLoading(true);
    try {
      const available = await checkUsernameAvailability(trimmed);
      if (!available) {
        setLoading(false);
        return Alert.alert('Błąd', 'Ten nick jest już zajęty');
      }

      const db = getFirestore();
      const userRef = doc(db, 'users', user.uid);
      const profileData = {
        username: trimmed,
        avatar: selectedAvatar,
        email: user.email,
        createdAt: serverTimestamp(),
        lastLoginAt: serverTimestamp(),
        quizzesPlayed: 0,
        totalPercentage: 0,
        totalQuizTime: 0,
        totalQuestionsAnswered: 0,
        currentStreak: 0,
        longestStreak: 0,
      };

      await setDoc(userRef, profileData);
      onProfileCreated(profileData);
    } catch (e) {
      console.error(e);
      Alert.alert('Błąd', 'Nie udało się ustawić profilu');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView
        contentContainerStyle={styles.container}
        keyboardShouldPersistTaps="handled"
      >
        <Text style={styles.title}>Ustaw swój profil</Text>

        <TextInput
          style={styles.input}
          placeholder="Nazwa użytkownika"
          placeholderTextColor="#999"
          value={username}
          onChangeText={setUsername}
          autoCapitalize="none"
          maxLength={20}
        />

        <Text style={styles.avatarTitle}>Wybierz avatar:</Text>
        <View style={styles.avatarGrid}>
          {Object.keys(avatarImages).map(av => (
            <TouchableOpacity
              key={av}
              onPress={() => setSelectedAvatar(av)}
              style={[
                styles.avatarOption,
                selectedAvatar === av && styles.selectedAvatar,
              ]}
            >
              <Image source={avatarImages[av]} style={styles.avatarImage} />
              <Text style={styles.avatarLabel}>{av}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity
          style={[styles.button, loading && styles.buttonDisabled]}
          onPress={handleProfileSetup}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#FFF" />
          ) : (
            <Text style={styles.buttonText}>Zapisz profil</Text>
          )}
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#1e1e1e' },
  container: {
    padding: 20,
    alignItems: 'center',
    paddingBottom: 40,
  },
  title: {
    fontSize: 32,
    color: '#4a90e2',
    marginBottom: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  input: {
    backgroundColor: '#333',
    color: '#FFF',
    padding: 15,
    marginVertical: 12,
    borderRadius: 12,
    width: '100%',
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#444',
  },
  avatarTitle: {
    alignSelf: 'flex-start',
    color: '#ccc',
    marginBottom: 12,
    fontSize: 20,
    fontWeight: '600',
  },
  avatarGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    marginBottom: 20,
  },
  avatarOption: {
    alignItems: 'center',
    margin: 10,
    padding: 10,
    borderRadius: 12,
    backgroundColor: '#444',
    width: 90,
    height: 120,
  },
  selectedAvatar: {
    borderColor: '#4a90e2',
    borderWidth: 4,
    backgroundColor: '#555',
  },
  avatarImage: {
    width: 70,
    height: 70,
    borderRadius: 35,
    marginBottom: 8,
  },
  avatarLabel: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#4a90e2',
    padding: 18,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 20,
    width: '100%',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
  },
  buttonDisabled: { opacity: 0.5 },
  buttonText: {
    color: '#FFF',
    fontWeight: 'bold',
    fontSize: 18,
  },
});

export default ProfileSetupScreen;

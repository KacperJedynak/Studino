import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  Image,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Modal,
  ScrollView,
  TouchableWithoutFeedback,
  TextInput,
  ImageBackground,
} from 'react-native';
import {
  getFirestore,
  collection,
  doc,
  onSnapshot,
  orderBy,
  query,
  getDocs,
  getDoc,
  updateDoc,
  arrayRemove,
  arrayUnion,
  increment,
} from '@react-native-firebase/firestore';
import { useNavigation } from '@react-navigation/native';

const subjectImages = {
  'Język polski': require('../images/subject_images/JezykPolski.png'),
  Matematyka: require('../images/subject_images/Matematyka.png'),
  'Język angielski': require('../images/subject_images/JezykAngielski.png'),
  'Język niemiecki': require('../images/subject_images/JezykNiemiecki.png'),
  'Język francuski': require('../images/subject_images/JezykFrancuski.png'),
  'Język hiszpański': require('../images/subject_images/JezykHiszpanski.png'),
  'Język rosyjski': require('../images/subject_images/JezykRosyjski.png'),
  'Język włoski': require('../images/subject_images/JezykWloski.png'),
  'Inny język': require('../images/subject_images/InneJezyki.png'),
  Informatyka: require('../images/subject_images/Informatyka.png'),
  Plastyka: require('../images/subject_images/Plastyka.png'),
  Muzyka: require('../images/subject_images/Muzyka.png'),
  WF: require('../images/subject_images/WF.png'),
  Religia: require('../images/subject_images/Religia.png'),
  Etyka: require('../images/subject_images/Etyka.png'),
  Historia: require('../images/subject_images/Historia.png'),
  Przyroda: require('../images/subject_images/Przyroda.png'),
  Biologia: require('../images/subject_images/Biologia.png'),
  Chemia: require('../images/subject_images/Chemia.png'),
  Fizyka: require('../images/subject_images/Fizyka.png'),
  Geografia: require('../images/subject_images/Geografia.png'),
  Technika: require('../images/subject_images/Technika.png'),
  'Wiedza o społeczeństwie': require('../images/subject_images/WOS.png'),
  'Edukacja dla bezpieczeństwa': require('../images/subject_images/EDB.png'),
  'Bezpieczeństwo i higiena pracy': require('../images/subject_images/BHP.png'),
  'Podstawy przedsiębiorczości': require('../images/subject_images/PodstawyPrzedsiebiorczosci.png'),
  'Historia sztuki': require('../images/subject_images/HistoriaSztuki.png'),
  Filozofia: require('../images/subject_images/Filozofia.png'),
  Inne: require('../images/subject_images/Inne.png'),
};

const icons = {
  like: require('../images/icons/like.png'),
  likeFilled: require('../images/icons/like-filled.png'),
  star: require('../images/icons/star.png'),
  starFilled: require('../images/icons/star-filled.png'),
};

const difficultyMap = { Łatwy: 1, Średni: 2, Trudny: 3 };
const levelMap = { Podstawowy: 1, Rozszerzony: 2 };

const getDifficultyStyle = difficulty => {
  switch (difficulty) {
    case 'Łatwy':
      return { color: '#4CAF50', backgroundColor: '#4CAF5020' };
    case 'Średni':
      return { color: '#FF9800', backgroundColor: '#FF980020' };
    case 'Trudny':
      return { color: '#F44336', backgroundColor: '#F4433620' };
    default:
      return { color: '#FF9800', backgroundColor: '#FF980020' };
  }
};

const getLevelStyle = level => {
  switch (level) {
    case 'Podstawowy':
      return { color: '#2196F3', backgroundColor: '#2196F320' };
    case 'Rozszerzony':
      return { color: '#9C27B0', backgroundColor: '#9C27B020' };
    default:
      return { color: '#2196F3', backgroundColor: '#2196F320' };
  }
};

export default function BrowseQuizesScreen({
  user,
  userProfile,
  onNavigateToQuiz,
}) {
  const navigation = useNavigation();
  const db = getFirestore();

  const [quizzes, setQuizzes] = useState([]);
  const [authorsMap, setAuthorsMap] = useState({});
  const [loading, setLoading] = useState(true);

  const [favorites, setFavorites] = useState(userProfile?.favorites || []);
  const [likedQuizzes, setLikedQuizzes] = useState(
    userProfile?.liked_quizzes || [],
  );

  const [searchBarText, setSearchBarText] = useState('');
  const [filterModalVis, setFilterModalVis] = useState(false);
  const [sortModalVis, setSortModalVis] = useState(false);

  const [subjectFilters, setSubjectFilters] = useState([]);
  const [typeFilters, setTypeFilters] = useState([1]);
  const [difficultyFilters, setDifficultyFilters] = useState([]);
  const [levelFilters, setLevelFilters] = useState([]);

  const [titleSort, setTitleSort] = useState(0);
  const [authorSort, setAuthorSort] = useState(0);
  const [difficultySort, setDifficultySort] = useState(0);
  const [levelSort, setLevelSort] = useState(0);
  const [subjectSort, setSubjectSort] = useState(0);
  const [likesSort, setLikesSort] = useState(0);
  const [playsSort, setPlaysSort] = useState(0);
  const [creationDateSort, setCreationDateSort] = useState(0);

  useEffect(() => {
    const quizzesRef = collection(db, 'quizzes');
    const q = query(quizzesRef, orderBy('created_at', 'desc'));

    const unsubscribe = onSnapshot(
      q,
      async snap => {
        const list = snap.docs.map(d => ({
          id: d.id,
          ...d.data(),
          level: d.data().level || 'Podstawowy',
        }));
        setQuizzes(list);

        const uids = [...new Set(list.map(q => q.created_by).filter(Boolean))];
        if (uids.length) {
          const map = {};
          for (const uid of uids) {
            try {
              const userDocRef = doc(db, 'users', uid);
              const userDocSnap = await getDoc(userDocRef);
              if (userDocSnap.exists()) {
                map[uid] = userDocSnap.data().username;
              }
            } catch (error) {
              console.error('Error fetching user:', error);
            }
          }
          setAuthorsMap(map);
        }
        setLoading(false);
      },
      err => {
        console.error(err);
        Alert.alert('Błąd', 'Nie udało się pobrać quizów.');
        setLoading(false);
      },
    );

    return () => unsubscribe();
  }, [db]);

  const fetchUserData = useCallback(async () => {
    if (!user) return;
    try {
      const userDocRef = doc(db, 'users', user.uid);
      const snap = await getDoc(userDocRef);
      const data = snap.data() || {};
      setFavorites(data.favorites || []);
      setLikedQuizzes(data.liked_quizzes || []);
    } catch (e) {
      console.error(e);
    }
  }, [user, db]);

  useEffect(() => {
    fetchUserData();
  }, [fetchUserData]);

  const quizzesMemo = useMemo(
    () =>
      quizzes.map(q => ({
        ...q,
        questionsCount: q.questions?.length || 0,
        playsCount: q.playsCount || 0,
        authorName:
          authorsMap[q.created_by] ??
          q.created_by_name ??
          (q.created_by === user.uid ? userProfile.username : null) ??
          'Nieznany',
        level: q.level || 'Podstawowy',
      })),
    [quizzes, authorsMap, user.uid, userProfile.username],
  );

  const filtered = useMemo(
    () =>
      quizzesMemo.filter(q => {
        const query = searchBarText.toLowerCase();
        if (
          query &&
          !q.title.toLowerCase().includes(query) &&
          !q.authorName.toLowerCase().includes(query)
        )
          return false;
        if (subjectFilters.length && !subjectFilters.includes(q.subject))
          return false;
        if (
          difficultyFilters.length &&
          !difficultyFilters.includes(difficultyMap[q.difficulty] || 2)
        )
          return false;
        if (
          levelFilters.length &&
          !levelFilters.includes(levelMap[q.level] || 1)
        )
          return false;
        if (typeFilters.includes(2) && !favorites.includes(q.id)) return false;
        if (typeFilters.includes(3) && !likedQuizzes.includes(q.id))
          return false;
        if (typeFilters.includes(4) && q.created_by !== user.uid) return false;
        return true;
      }),
    [
      quizzesMemo,
      searchBarText,
      subjectFilters,
      difficultyFilters,
      levelFilters,
      typeFilters,
      favorites,
      likedQuizzes,
      user.uid,
    ],
  );

  const sorted = useMemo(() => {
    const arr = [...filtered];
    const applySort = (get, mode) => {
      if (!mode) return;
      arr.sort((a, b) => {
        const valueA = get(a);
        const valueB = get(b);

        if (typeof valueA === 'string' && typeof valueB === 'string') {
          const comparison = valueA
            .toLowerCase()
            .localeCompare(valueB.toLowerCase());
          return mode === 1 ? comparison : -comparison;
        }

        return mode === 1
          ? valueA > valueB
            ? 1
            : -1
          : valueA < valueB
          ? 1
          : -1;
      });
    };

    applySort(q => q.title, titleSort);
    applySort(q => q.authorName, authorSort);
    applySort(q => difficultyMap[q.difficulty] || 2, difficultySort);
    applySort(q => levelMap[q.level] || 1, levelSort);
    applySort(q => q.subject, subjectSort);
    applySort(q => q.likes || 0, likesSort);
    applySort(q => q.playsCount || 0, playsSort);
    applySort(
      q => q.created_at?.toMillis() || 0,
      creationDateSort === 1 ? 2 : creationDateSort === 2 ? 1 : 0,
    );
    return arr;
  }, [
    filtered,
    titleSort,
    authorSort,
    difficultySort,
    levelSort,
    subjectSort,
    likesSort,
    playsSort,
    creationDateSort,
  ]);

  const toggleFavorite = async quizId => {
    const yes = favorites.includes(quizId);
    setFavorites(prev =>
      yes ? prev.filter(id => id !== quizId) : [...prev, quizId],
    );
    try {
      const userDocRef = doc(db, 'users', user.uid);
      await updateDoc(userDocRef, {
        favorites: yes ? arrayRemove(quizId) : arrayUnion(quizId),
      });
    } catch {
      Alert.alert('Błąd', 'Nie udało się zaktualizować ulubionych.');
      setFavorites(prev =>
        yes ? [...prev, quizId] : prev.filter(id => id !== quizId),
      );
    }
  };

  const toggleLike = async quizId => {
    const yes = likedQuizzes.includes(quizId);
    setQuizzes(prev =>
      prev.map(q =>
        q.id === quizId ? { ...q, likes: (q.likes || 0) + (yes ? -1 : +1) } : q,
      ),
    );
    setLikedQuizzes(prev =>
      yes ? prev.filter(id => id !== quizId) : [...prev, quizId],
    );
    try {
      const userRef = doc(db, 'users', user.uid);
      const quizRef = doc(db, 'quizzes', quizId);

      await updateDoc(userRef, {
        liked_quizzes: yes ? arrayRemove(quizId) : arrayUnion(quizId),
      });

      await updateDoc(quizRef, {
        likes: yes ? increment(-1) : increment(1),
      });
    } catch {
      Alert.alert('Błąd', 'Nie udało się zaktualizować lajków.');
    }
  };

  const renderQuizItem = ({ item }) => {
    const isFav = favorites.includes(item.id);
    const isLiked = likedQuizzes.includes(item.id);

    return (
      <View style={styles.quizCard}>
        <ImageBackground
          source={subjectImages[item.subject]}
          style={styles.cardBackground}
          imageStyle={styles.backgroundImage}
          resizeMode="contain"
        >
          <TouchableOpacity
            style={styles.cardContent}
            onPress={() => onNavigateToQuiz(item)}
          >
            <View style={styles.cardHeader}>
              <View style={styles.titleSection}>
                <Text style={styles.quizTitle}>{item.title}</Text>
                <Text style={styles.subjectBadge}>{item.subject}</Text>
              </View>
              <View style={styles.headerActions}>
                <TouchableOpacity onPress={() => toggleFavorite(item.id)}>
                  <Image
                    source={isFav ? icons.starFilled : icons.star}
                    style={styles.icon}
                  />
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.likeButton}
                  onPress={() => toggleLike(item.id)}
                >
                  <Image
                    source={isLiked ? icons.likeFilled : icons.like}
                    style={styles.icon}
                  />
                  <Text style={styles.likesCount}>{item.likes || 0}</Text>
                </TouchableOpacity>
              </View>
            </View>
            <View style={styles.quizInfo}>
              <View style={styles.detailsRow}>
                <Text
                  style={[
                    styles.difficultyBadge,
                    getDifficultyStyle(item.difficulty),
                  ]}
                >
                  {item.difficulty}
                </Text>
                <Text style={[styles.levelBadge, getLevelStyle(item.level)]}>
                  {item.level}
                </Text>
              </View>
              <View style={styles.statsRow}>
                <Text style={styles.quizStat}>
                  Pytania: {item.questionsCount}
                </Text>
                <Text style={styles.quizDetail}>Autor: {item.authorName}</Text>
                <Text style={styles.quizStat}>
                  Rozegrane: {item.playsCount}
                </Text>
              </View>
            </View>
          </TouchableOpacity>
        </ImageBackground>
      </View>
    );
  };

  const getSortLabels = sortType => {
    if (
      sortType === 'title' ||
      sortType === 'author' ||
      sortType === 'subject'
    ) {
      return [
        { id: 0, label: 'Brak' },
        { id: 1, label: 'A-Z' },
        { id: 2, label: 'Z-A' },
      ];
    } else if (sortType === 'creationDate') {
      return [
        { id: 0, label: 'Brak' },
        { id: 1, label: 'Najstarsze' },
        { id: 2, label: 'Najnowsze' },
      ];
    } else {
      return [
        { id: 0, label: 'Brak' },
        { id: 1, label: 'Rosnąco' },
        { id: 2, label: 'Malejąco' },
      ];
    }
  };

  if (loading)
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#6495ED" />
        <Text style={styles.loadingText}>Ładowanie...</Text>
      </View>
    );

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={styles.backButton}
        onPress={() => navigation.goBack()}
      >
        <Text style={styles.backArrow}>← Powrót</Text>
      </TouchableOpacity>

      <Text style={styles.header}>Quizy</Text>

      <View style={styles.searchBarContainer}>
        <TextInput
          style={styles.searchBar}
          placeholder="Wyszukaj..."
          placeholderTextColor="#aaa"
          value={searchBarText}
          onChangeText={setSearchBarText}
        />
        <TouchableOpacity
          style={styles.filterButton}
          onPress={() => setFilterModalVis(true)}
        >
          <Text style={styles.filterText}>Filtry</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.sortButton}
          onPress={() => setSortModalVis(true)}
        >
          <Text style={styles.filterText}>Sortuj</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={sorted}
        renderItem={renderQuizItem}
        keyExtractor={i => i.id}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          !loading && (
            <Text style={styles.noQuizzesText}>
              Brak quizów do wyświetlenia
            </Text>
          )
        }
      />

      <Modal visible={filterModalVis} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <TouchableWithoutFeedback onPress={() => setFilterModalVis(false)}>
            <View style={styles.backdrop} />
          </TouchableWithoutFeedback>
          <View style={styles.modalContent}>
            <ScrollView>
              <Text style={styles.modalTitle}>Filtry</Text>

              <Text style={styles.modalLabel}>Przedmiot:</Text>
              <View style={styles.chipContainer}>
                {Object.keys(subjectImages).map(subj => (
                  <TouchableOpacity
                    key={subj}
                    style={[
                      styles.filterChip,
                      subjectFilters.includes(subj) && styles.filterChipActive,
                    ]}
                    onPress={() =>
                      setSubjectFilters(prev =>
                        prev.includes(subj)
                          ? prev.filter(x => x !== subj)
                          : [...prev, subj],
                      )
                    }
                  >
                    <Text
                      style={[
                        styles.chipText,
                        subjectFilters.includes(subj) && styles.chipTextActive,
                      ]}
                    >
                      {subj}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={styles.modalLabel}>Typ:</Text>
              <View style={styles.chipContainer}>
                {[
                  { id: 1, label: 'Wszystkie' },
                  { id: 2, label: 'Ulubione' },
                  { id: 3, label: 'Polubione' },
                  { id: 4, label: 'Twoje' },
                ].map(opt => (
                  <TouchableOpacity
                    key={opt.id}
                    style={[
                      styles.filterChip,
                      typeFilters.includes(opt.id) && styles.filterChipActive,
                    ]}
                    onPress={() => setTypeFilters([opt.id])}
                  >
                    <Text
                      style={[
                        styles.chipText,
                        typeFilters.includes(opt.id) && styles.chipTextActive,
                      ]}
                    >
                      {opt.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={styles.modalLabel}>Trudność:</Text>
              <View style={styles.chipContainer}>
                {[
                  { id: 1, label: 'Łatwy' },
                  { id: 2, label: 'Średni' },
                  { id: 3, label: 'Trudny' },
                ].map(opt => (
                  <TouchableOpacity
                    key={opt.id}
                    style={[
                      styles.filterChip,
                      difficultyFilters.includes(opt.id) &&
                        styles.filterChipActive,
                    ]}
                    onPress={() =>
                      setDifficultyFilters(prev =>
                        prev.includes(opt.id)
                          ? prev.filter(x => x !== opt.id)
                          : [...prev, opt.id],
                      )
                    }
                  >
                    <Text
                      style={[
                        styles.chipText,
                        difficultyFilters.includes(opt.id) &&
                          styles.chipTextActive,
                      ]}
                    >
                      {opt.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={styles.modalLabel}>Poziom zaawansowania:</Text>
              <View style={styles.chipContainer}>
                {[
                  { id: 1, label: 'Podstawowy' },
                  { id: 2, label: 'Rozszerzony' },
                ].map(opt => (
                  <TouchableOpacity
                    key={opt.id}
                    style={[
                      styles.filterChip,
                      levelFilters.includes(opt.id) && styles.filterChipActive,
                    ]}
                    onPress={() =>
                      setLevelFilters(prev =>
                        prev.includes(opt.id)
                          ? prev.filter(x => x !== opt.id)
                          : [...prev, opt.id],
                      )
                    }
                  >
                    <Text
                      style={[
                        styles.chipText,
                        levelFilters.includes(opt.id) && styles.chipTextActive,
                      ]}
                    >
                      {opt.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              <View style={styles.modalActionsRow}>
                <TouchableOpacity
                  onPress={() => {
                    setSubjectFilters([]);
                    setTypeFilters([1]);
                    setDifficultyFilters([]);
                    setLevelFilters([]);
                  }}
                >
                  <Text style={styles.modalActionText}>Wyczyść</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => setFilterModalVis(false)}>
                  <Text style={styles.modalActionText}>Zamknij</Text>
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>

      <Modal visible={sortModalVis} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <TouchableWithoutFeedback onPress={() => setSortModalVis(false)}>
            <View style={styles.backdrop} />
          </TouchableWithoutFeedback>
          <View style={styles.modalContent}>
            <ScrollView>
              <Text style={styles.modalTitle}>Sortowanie</Text>
              {[
                {
                  label: 'Tytuł',
                  state: titleSort,
                  set: setTitleSort,
                  type: 'title',
                },
                {
                  label: 'Autor',
                  state: authorSort,
                  set: setAuthorSort,
                  type: 'author',
                },
                {
                  label: 'Trudność',
                  state: difficultySort,
                  set: setDifficultySort,
                  type: 'difficulty',
                },
                {
                  label: 'Poziom zaawansowania',
                  state: levelSort,
                  set: setLevelSort,
                  type: 'level',
                },
                {
                  label: 'Przedmiot',
                  state: subjectSort,
                  set: setSubjectSort,
                  type: 'subject',
                },
                {
                  label: 'Polubienia',
                  state: likesSort,
                  set: setLikesSort,
                  type: 'likes',
                },
                {
                  label: 'Rozegrane',
                  state: playsSort,
                  set: setPlaysSort,
                  type: 'plays',
                },
                {
                  label: 'Data utworzenia',
                  state: creationDateSort,
                  set: setCreationDateSort,
                  type: 'creationDate',
                },
              ].map(opt => (
                <View key={opt.label}>
                  <Text style={styles.modalLabel}>{opt.label}:</Text>
                  <View style={styles.chipContainer}>
                    {getSortLabels(opt.type).map(o => (
                      <TouchableOpacity
                        key={o.id}
                        style={[
                          styles.filterChip,
                          opt.state === o.id && styles.filterChipActive,
                        ]}
                        onPress={() => opt.set(o.id)}
                      >
                        <Text
                          style={[
                            styles.chipText,
                            opt.state === o.id && styles.chipTextActive,
                          ]}
                        >
                          {o.label}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
              ))}
              <View style={styles.modalActionsRow}>
                <TouchableOpacity
                  onPress={() => {
                    setTitleSort(0);
                    setAuthorSort(0);
                    setDifficultySort(0);
                    setLevelSort(0);
                    setSubjectSort(0);
                    setLikesSort(0);
                    setPlaysSort(0);
                    setCreationDateSort(0);
                  }}
                >
                  <Text style={styles.modalActionText}>Wyczyść</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => setSortModalVis(false)}>
                  <Text style={styles.modalActionText}>Zamknij</Text>
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1a1a1a',
    padding: 12,
    paddingTop: 60,
  },
  backButton: { position: 'absolute', top: 20, left: 12, zIndex: 1 },
  backArrow: { color: '#6495ED', fontSize: 16, fontWeight: '600' },
  header: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 10,
    textAlign: 'center',
  },
  searchBarContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  searchBar: {
    flex: 1,
    height: 40,
    borderColor: '#6495ED',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 10,
    color: '#fff',
    backgroundColor: '#2a2a2a',
  },
  filterButton: {
    marginLeft: 8,
    padding: 8,
    backgroundColor: '#6495ED20',
    borderRadius: 6,
  },
  sortButton: {
    marginLeft: 8,
    padding: 8,
    backgroundColor: '#6495ED20',
    borderRadius: 6,
  },
  filterText: { color: '#6495ED', fontWeight: '600' },
  listContent: { paddingBottom: 100 },
  quizCard: {
    marginVertical: 6,
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 3,
    backgroundColor: '#2a2a2a',
  },
  cardBackground: { flex: 1 },
  backgroundImage: {
    opacity: 0.1,
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: [{ translateX: -50 }, { translateY: -50 }],
    width: 80,
    height: 80,
  },
  cardContent: {},
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    padding: 12,
    paddingBottom: 4,
  },
  titleSection: { flex: 1, paddingRight: 12 },
  quizTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 4,
    lineHeight: 26,
  },
  subjectBadge: {
    fontSize: 16,
    color: '#fcff61',
    fontWeight: 'bold',
    marginBottom: 4,
    alignSelf: 'flex-start',
  },
  headerActions: { flexDirection: 'row', gap: 8, alignItems: 'center' },
  likeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#333',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    gap: 4,
  },
  icon: { width: 20, height: 20 },
  likesCount: { color: '#fff', fontSize: 12, fontWeight: '600' },
  quizInfo: { paddingHorizontal: 12, paddingTop: 4, paddingBottom: 12 },
  detailsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 8,
  },
  difficultyBadge: {
    fontSize: 12,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    fontWeight: '600',
  },
  levelBadge: {
    fontSize: 12,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    fontWeight: '600',
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 4,
  },
  quizStat: { fontSize: 13, color: '#999', fontWeight: '500' },
  quizDetail: { fontSize: 13, color: '#999', fontWeight: '500' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: '#6495ED', marginTop: 12 },
  noQuizzesText: {
    color: '#ccc',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 50,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
  },
  backdrop: { position: 'absolute', width: '100%', height: '100%' },
  modalContent: {
    marginHorizontal: 20,
    backgroundColor: '#2a2a2a',
    borderRadius: 12,
    padding: 20,
    maxHeight: '80%',
    zIndex: 10,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 16,
    textAlign: 'center',
  },
  modalLabel: {
    color: '#fff',
    fontWeight: '600',
    marginTop: 12,
    marginBottom: 6,
  },
  chipContainer: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 8 },
  filterChip: {
    borderWidth: 1,
    borderColor: '#6495ED',
    borderRadius: 20,
    paddingVertical: 8,
    paddingHorizontal: 14,
    margin: 4,
    backgroundColor: '#1a1a1a',
  },
  filterChipActive: { backgroundColor: '#6495ED' },
  chipText: { color: '#fff', fontSize: 14 },
  chipTextActive: { color: '#fff', fontSize: 14, fontWeight: '600' },
  modalActionsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  modalActionText: { fontSize: 16, fontWeight: '600', color: '#6495ED' },
});

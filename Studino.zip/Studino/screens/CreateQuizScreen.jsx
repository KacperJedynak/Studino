import React, { useState, useCallback, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Modal,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  BackHandler,
} from 'react-native';
import { Dropdown } from 'react-native-element-dropdown';
import uuid from 'react-native-uuid';

import { getApp } from '@react-native-firebase/app';
import {
  getFirestore,
  collection,
  addDoc,
  doc,
  updateDoc,
  serverTimestamp,
  increment,
} from '@react-native-firebase/firestore';
import { getAuth } from '@react-native-firebase/auth';

import { useNavigation, useRoute } from '@react-navigation/native';

const app = getApp();
const db = getFirestore(app);
const authInstance = getAuth(app);

const SUBJECTS = [
  { label: 'Język polski', value: 'Język polski' },
  { label: 'Matematyka', value: 'Matematyka' },
  { label: 'Język angielski', value: 'Język angielski' },
  { label: 'Język niemiecki', value: 'Język niemiecki' },
  { label: 'Język francuski', value: 'Język francuski' },
  { label: 'Język hiszpański', value: 'Język hiszpański' },
  { label: 'Język rosyjski', value: 'Język rosyjski' },
  { label: 'Język włoski', value: 'Język włoski' },
  { label: 'Inny język', value: 'Inny język' },
  { label: 'Informatyka', value: 'Informatyka' },
  { label: 'Plastyka', value: 'Plastyka' },
  { label: 'Muzyka', value: 'Muzyka' },
  { label: 'WF', value: 'WF' },
  { label: 'Religia', value: 'Religia' },
  { label: 'Etyka', value: 'Etyka' },
  { label: 'Historia', value: 'Historia' },
  { label: 'Przyroda', value: 'Przyroda' },
  { label: 'Biologia', value: 'Biologia' },
  { label: 'Chemia', value: 'Chemia' },
  { label: 'Fizyka', value: 'Fizyka' },
  { label: 'Geografia', value: 'Geografia' },
  { label: 'Technika', value: 'Technika' },
  { label: 'Wiedza o społeczeństwie', value: 'Wiedza o społeczeństwie' },
  {
    label: 'Edukacja dla bezpieczeństwa',
    value: 'Edukacja dla bezpieczeństwa',
  },
  {
    label: 'Bezpieczeństwo i higiena pracy',
    value: 'Bezpieczeństwo i higiena pracy',
  },
  {
    label: 'Podstawy przedsiębiorczości',
    value: 'Podstawy przedsiębiorczości',
  },
  { label: 'Historia sztuki', value: 'Historia sztuki' },
  { label: 'Filozofia', value: 'Filozofia' },
  { label: 'Inne', value: 'Inne' },
];

const LEVELS = [
  { label: 'Podstawowy', value: 'Podstawowy' },
  { label: 'Rozszerzony', value: 'Rozszerzony' },
];

const DIFFICULTIES = [
  { label: 'Łatwy', value: 'Łatwy' },
  { label: 'Średni', value: 'Średni' },
  { label: 'Trudny', value: 'Trudny' },
];

const QUESTION_TYPES = [
  { label: 'Wielokrotny wybór', value: 'mcq' },
  { label: 'Tekst/Liczba', value: 'text' },
  { label: 'Prawda/Fałsz', value: 'boolean' },
];

const Header = React.memo(
  ({
    title,
    setTitle,
    subject,
    setSubject,
    level,
    setLevel,
    difficulty,
    setDifficulty,
    description,
    setDescription,
    openAddModal,
  }) => (
    <View style={styles.headerContainer}>
      <Text style={styles.label}>Tytuł quizu</Text>
      <TextInput
        style={styles.input}
        value={title}
        onChangeText={setTitle}
        placeholder="Wpisz tytuł"
        placeholderTextColor="#A0A0A0"
        returnKeyType="done"
        autoCapitalize="sentences"
      />
      <Text style={styles.label}>Przedmiot</Text>
      <Dropdown
        style={styles.dropdown}
        placeholderStyle={styles.placeholderStyle}
        selectedTextStyle={styles.selectedTextStyle}
        inputSearchStyle={styles.inputSearchStyle}
        iconStyle={styles.iconStyle}
        data={SUBJECTS}
        maxHeight={300}
        labelField="label"
        valueField="value"
        placeholder="Wybierz przedmiot"
        value={subject}
        onChange={item => setSubject(item.value)}
        containerStyle={styles.dropdownContainer}
        itemContainerStyle={styles.itemContainer}
        itemTextStyle={styles.itemText}
        activeColor="#555"
      />
      <Text style={styles.label}>Poziom zaawansowania</Text>
      <Dropdown
        style={styles.dropdown}
        placeholderStyle={styles.placeholderStyle}
        selectedTextStyle={styles.selectedTextStyle}
        inputSearchStyle={styles.inputSearchStyle}
        iconStyle={styles.iconStyle}
        data={LEVELS}
        maxHeight={300}
        labelField="label"
        valueField="value"
        placeholder="Wybierz poziom"
        value={level}
        onChange={item => setLevel(item.value)}
        containerStyle={styles.dropdownContainer}
        itemContainerStyle={styles.itemContainer}
        itemTextStyle={styles.itemText}
        activeColor="#555"
      />
      <Text style={styles.label}>Stopień trudności</Text>
      <Dropdown
        style={styles.dropdown}
        placeholderStyle={styles.placeholderStyle}
        selectedTextStyle={styles.selectedTextStyle}
        inputSearchStyle={styles.inputSearchStyle}
        iconStyle={styles.iconStyle}
        data={DIFFICULTIES}
        maxHeight={300}
        labelField="label"
        valueField="value"
        placeholder="Wybierz trudność"
        value={difficulty}
        onChange={item => setDifficulty(item.value)}
        containerStyle={styles.dropdownContainer}
        itemContainerStyle={styles.itemContainer}
        itemTextStyle={styles.itemText}
        activeColor="#555"
      />
      <Text style={styles.label}>Opis (opcjonalny)</Text>
      <TextInput
        style={[styles.input, { height: 80 }]}
        value={description}
        onChangeText={setDescription}
        placeholder="Opis quizu"
        placeholderTextColor="#A0A0A0"
        returnKeyType="done"
        autoCapitalize="sentences"
      />
      <TouchableOpacity style={styles.addBtn} onPress={openAddModal}>
        <Text style={styles.addBtnText}>+ Dodaj pytanie</Text>
      </TouchableOpacity>
    </View>
  ),
);

export default function CreateQuizScreen({ userProfile }) {
  const navigation = useNavigation();
  const route = useRoute();
  const quizToEdit = route.params?.quizToEdit;

  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState(SUBJECTS[0].value);
  const [level, setLevel] = useState(LEVELS[0].value);
  const [difficulty, setDifficulty] = useState(DIFFICULTIES[0].value);
  const [description, setDescription] = useState('');
  const [questions, setQuestions] = useState([]);

  const [modalVisible, setModalVisible] = useState(false);
  const [editIndex, setEditIndex] = useState(null);
  const [qForm, setQForm] = useState({
    id: uuid.v4(),
    question: '',
    type: 'mcq',
    options: ['', '', '', ''],
    correctIndexes: [],
    answer: '',
  });

  const validateNonEmpty = useCallback(str => str.trim().length > 0, []);

  useEffect(() => {
    if (quizToEdit) {
      setTitle(quizToEdit.title);
      setSubject(quizToEdit.subject);
      setLevel(quizToEdit.level);
      setDifficulty(quizToEdit.difficulty);
      setDescription(quizToEdit.description || '');
      setQuestions(quizToEdit.questions || []);
    }
  }, [quizToEdit]);

  const confirmCancel = () => {
    Alert.alert(
      'Anulować tworzenie quizu?',
      'Wszystkie niezapisane zmiany zostaną utracone.',
      [
        { text: 'Nie', style: 'cancel' },
        {
          text: 'Tak',
          style: 'destructive',
          onPress: () => navigation.goBack(),
        },
      ],
    );
  };

  useEffect(() => {
    const handler = BackHandler.addEventListener('hardwareBackPress', () => {
      confirmCancel();
      return true;
    });
    return () => handler.remove();
  }, []);

  const openAddModal = () => {
    setEditIndex(null);
    setQForm({
      id: uuid.v4(),
      question: '',
      type: 'mcq',
      options: ['', '', '', ''],
      correctIndexes: [],
      answer: '',
    });
    setModalVisible(true);
  };

  const saveQuestion = () => {
    if (!validateNonEmpty(qForm.question)) {
      return Alert.alert('Błąd', 'Wpisz treść pytania.');
    }
    if (qForm.type === 'mcq') {
      for (let i = 0; i < 4; i++) {
        if (!validateNonEmpty(qForm.options[i])) {
          return Alert.alert('Błąd', `Wpisz opcję ${i + 1}.`);
        }
      }
      if (qForm.correctIndexes.length === 0) {
        return Alert.alert(
          'Błąd',
          'Zaznacz przynajmniej jedną poprawną odpowiedź.',
        );
      }
    }
    if (
      (qForm.type === 'text' || qForm.type === 'boolean') &&
      qForm.answer === ''
    ) {
      return Alert.alert('Błąd', 'Wpisz lub wybierz odpowiedź.');
    }

    const list = [...questions];
    if (editIndex !== null) {
      list[editIndex] = qForm;
    } else {
      list.push({ ...qForm });
    }
    setQuestions(list);
    setModalVisible(false);
  };

  const toggleCorrect = idx => {
    const ci = qForm.correctIndexes.includes(idx)
      ? qForm.correctIndexes.filter(i => i !== idx)
      : [...qForm.correctIndexes, idx];
    setQForm(f => ({ ...f, correctIndexes: ci }));
  };

  const renderQuestionItem = (item, index) => (
    <View key={item.id} style={styles.questionItem}>
      <Text style={styles.questionText}>{`${index + 1}. ${
        item.question
      }`}</Text>
      <View style={styles.qButtons}>
        <TouchableOpacity
          onPress={() => {
            setEditIndex(index);
            setQForm(item);
            setModalVisible(true);
          }}
        >
          <Text style={styles.editBtn}>Edytuj</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => {
            Alert.alert('Usuń pytanie', 'Czy na pewno?', [
              { text: 'Anuluj', style: 'cancel' },
              {
                text: 'Usuń',
                style: 'destructive',
                onPress: () =>
                  setQuestions(qs => qs.filter((_, i) => i !== index)),
              },
            ]);
          }}
        >
          <Text style={styles.deleteBtn}>Usuń</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  const saveQuizToFirestore = async () => {
    if (!validateNonEmpty(title)) {
      return Alert.alert('Błąd', 'Tytuł nie może być pusty.');
    }
    if (questions.length === 0) {
      return Alert.alert('Błąd', 'Dodaj przynajmniej jedno pytanie.');
    }

    const user = authInstance.currentUser;
    const userId = user.uid;
    const quizData = {
      title: title.trim(),
      subject,
      level,
      difficulty,
      description: description.trim(),
      created_by: userId,
      created_by_name: userProfile.username,
      questions: questions.map(q => {
        const base = { id: q.id, question: q.question.trim(), type: q.type };
        if (q.type === 'mcq') {
          return {
            ...base,
            options: q.options.map(o => o.trim()),
            correctIndexes: q.correctIndexes,
          };
        } else {
          return { ...base, answer: q.answer };
        }
      }),
    };

    try {
      if (quizToEdit) {
        const quizRef = doc(db, 'quizzes', quizToEdit.id);
        await updateDoc(quizRef, {
          ...quizData,
          updated_at: serverTimestamp(),
        });
        Alert.alert('Sukces', 'Quiz został zaktualizowany!');
      } else {
        const quizzesRef = collection(db, 'quizzes');
        await addDoc(quizzesRef, {
          ...quizData,
          created_at: serverTimestamp(),
          likes: 0,
          playsCount: 0,
          created_by_name: userProfile.username,
        });
        const userRef = doc(db, 'users', userId);
        await updateDoc(userRef, { quizzesCreated: increment(1) });
        Alert.alert('Sukces', 'Quiz został zapisany!');
      }
      navigation.replace('QuizSelectScreen');
    } catch (error) {
      console.error(error);
      Alert.alert('Błąd', 'Nie udało się zapisać quizu. Spróbuj ponownie.');
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      style={styles.keyboardView}
    >
      <ScrollView style={styles.container} keyboardShouldPersistTaps="always">
        <Header
          title={title}
          setTitle={setTitle}
          subject={subject}
          setSubject={setSubject}
          level={level}
          setLevel={setLevel}
          difficulty={difficulty}
          setDifficulty={setDifficulty}
          description={description}
          setDescription={setDescription}
          openAddModal={openAddModal}
        />
        {questions.map((q, i) => renderQuestionItem(q, i))}
        <TouchableOpacity style={styles.cancelQuizBtn} onPress={confirmCancel}>
          <Text style={styles.cancelQuizBtnText}>Anuluj</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.submitBtn}
          onPress={saveQuizToFirestore}
        >
          <Text style={styles.submitBtnText}>
            {quizToEdit ? 'Zapisz zmiany' : 'Zapisz quiz'}
          </Text>
        </TouchableOpacity>
      </ScrollView>

      <Modal
        visible={modalVisible}
        animationType="slide"
        onRequestClose={() => setModalVisible(false)}
      >
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          style={styles.modalView}
        >
          <ScrollView keyboardShouldPersistTaps="handled">
            <Text style={styles.label}>Treść pytania</Text>
            <TextInput
              style={styles.input}
              value={qForm.question}
              onChangeText={text => setQForm(f => ({ ...f, question: text }))}
              placeholder="Wpisz pytanie"
              placeholderTextColor="#A0A0A0"
              multiline
              autoCapitalize="sentences"
            />
            <Text style={styles.label}>Typ pytania</Text>
            <Dropdown
              style={styles.dropdown}
              placeholderStyle={styles.placeholderStyle}
              selectedTextStyle={styles.selectedTextStyle}
              iconStyle={styles.iconStyle}
              data={QUESTION_TYPES}
              maxHeight={300}
              labelField="label"
              valueField="value"
              placeholder="Wybierz typ pytania"
              value={qForm.type}
              onChange={item => {
                const type = item.value;
                setQForm({
                  id: uuid.v4(),
                  question: '',
                  type,
                  options: type === 'mcq' ? ['', '', '', ''] : [],
                  correctIndexes: [],
                  answer: type === 'boolean' ? true : '',
                });
              }}
              containerStyle={styles.dropdownContainer}
              itemContainerStyle={styles.itemContainer}
              itemTextStyle={styles.itemText}
              activeColor="#555"
            />
            {qForm.type === 'mcq' &&
              qForm.options.map((opt, idx) => (
                <View key={idx} style={styles.optionRow}>
                  <TouchableOpacity
                    style={[
                      styles.checkbox,
                      qForm.correctIndexes.includes(idx) && styles.checkedBox,
                    ]}
                    onPress={() => toggleCorrect(idx)}
                  >
                    {qForm.correctIndexes.includes(idx) && (
                      <Text style={styles.checkmark}>✓</Text>
                    )}
                  </TouchableOpacity>
                  <TextInput
                    style={styles.optionInput}
                    value={opt}
                    onChangeText={text => {
                      const newOpts = [...qForm.options];
                      newOpts[idx] = text;
                      setQForm(f => ({ ...f, options: newOpts }));
                    }}
                    placeholder={`Opcja ${idx + 1}`}
                    placeholderTextColor="#A0A0A0"
                    autoCapitalize="sentences"
                  />
                </View>
              ))}
            {qForm.type === 'text' && (
              <>
                <Text style={styles.label}>Poprawna odpowiedź</Text>
                <TextInput
                  style={styles.input}
                  value={qForm.answer}
                  onChangeText={text => setQForm(f => ({ ...f, answer: text }))}
                  placeholder="Wpisz odpowiedź"
                  placeholderTextColor="#A0A0A0"
                  autoCapitalize="sentences"
                />
              </>
            )}
            {qForm.type === 'boolean' && (
              <>
                <Text style={styles.label}>Poprawna odpowiedź</Text>
                <View style={styles.boolRow}>
                  <TouchableOpacity
                    style={[
                      styles.boolBtn,
                      qForm.answer === true && styles.boolBtnSelected,
                    ]}
                    onPress={() => setQForm(f => ({ ...f, answer: true }))}
                  >
                    <Text style={styles.boolBtnText}>Prawda</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[
                      styles.boolBtn,
                      qForm.answer === false && styles.boolBtnSelected,
                    ]}
                    onPress={() => setQForm(f => ({ ...f, answer: false }))}
                  >
                    <Text style={styles.boolBtnText}>Fałsz</Text>
                  </TouchableOpacity>
                </View>
              </>
            )}
            <View style={styles.modalBtns}>
              <TouchableOpacity
                style={styles.cancelBtn}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.cancelBtnText}>Anuluj</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveBtn} onPress={saveQuestion}>
                <Text style={styles.saveBtnText}>Zapisz pytanie</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </Modal>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  keyboardView: { flex: 1 },
  container: {
    padding: 16,
    backgroundColor: '#1F1F1F',
    flex: 1,
  },
  headerContainer: { marginBottom: 24 },
  label: {
    fontWeight: '600',
    fontSize: 16,
    marginBottom: 8,
    color: '#FFF',
    marginTop: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#555',
    borderRadius: 8,
    padding: 14,
    fontSize: 16,
    marginBottom: 16,
    color: '#FFF',
    backgroundColor: '#303030',
  },
  dropdown: {
    height: 50,
    backgroundColor: '#303030',
    borderRadius: 8,
    padding: 12,
    borderWidth: 1,
    borderColor: '#555',
    marginBottom: 16,
  },
  placeholderStyle: {
    fontSize: 16,
    color: '#A0A0A0',
  },
  selectedTextStyle: {
    fontSize: 16,
    color: '#FFF',
  },
  iconStyle: {
    width: 20,
    height: 20,
    tintColor: '#999',
  },
  inputSearchStyle: {
    height: 40,
    fontSize: 16,
    backgroundColor: '#252525',
    borderRadius: 6,
    color: '#FFF',
    paddingHorizontal: 12,
  },
  dropdownContainer: {
    backgroundColor: '#252525',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#555',
    shadowColor: '#101010',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 4,
    elevation: 5,
  },
  itemContainer: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderBottomWidth: 0.5,
    borderBottomColor: '#555',
  },
  itemText: {
    fontSize: 16,
    color: '#FFF',
  },
  addBtn: {
    backgroundColor: '#40BF4A',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 8,
    shadowColor: '#101010',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  addBtnText: {
    color: '#FFF',
    fontWeight: '600',
    fontSize: 18,
  },
  questionItem: {
    backgroundColor: '#353535',
    padding: 16,
    marginBottom: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#555',
  },
  questionText: {
    fontSize: 16,
    marginBottom: 12,
    color: '#FFF',
    lineHeight: 22,
  },
  qButtons: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  editBtn: {
    color: '#00AAFF',
    marginRight: 20,
    fontSize: 16,
    fontWeight: '500',
  },
  deleteBtn: {
    color: '#DF2020',
    fontSize: 16,
    fontWeight: '500',
  },
  cancelQuizBtn: {
    backgroundColor: '#DF2020',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginVertical: 12,
    shadowColor: '#101010',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  cancelQuizBtnText: {
    color: '#FFF',
    fontWeight: '600',
    fontSize: 18,
  },
  submitBtn: {
    backgroundColor: '#00AAFF',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 40,
    shadowColor: '#101010',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  submitBtnText: {
    color: '#FFF',
    fontWeight: '600',
    fontSize: 18,
  },
  modalView: {
    flex: 1,
    padding: 16,
    backgroundColor: '#1F1F1F',
  },
  optionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  checkbox: {
    width: 32,
    height: 32,
    borderWidth: 2,
    borderColor: '#555',
    borderRadius: 6,
    marginRight: 12,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#303030',
  },
  checkedBox: {
    backgroundColor: '#40BF4A',
    borderColor: '#40BF4A',
  },
  checkmark: {
    color: '#FFF',
    fontWeight: 'bold',
    fontSize: 18,
  },
  optionInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#555',
    borderRadius: 6,
    padding: 12,
    fontSize: 16,
    color: '#FFF',
    backgroundColor: '#303030',
  },
  boolRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginVertical: 16,
  },
  boolBtn: {
    borderWidth: 2,
    borderColor: '#555',
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 24,
    backgroundColor: '#303030',
    minWidth: 100,
    alignItems: 'center',
  },
  boolBtnSelected: {
    backgroundColor: '#AA00AA',
    borderColor: '#FF00FF',
  },
  boolBtnText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '500',
  },
  modalBtns: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 32,
    marginBottom: 20,
  },
  cancelBtn: {
    backgroundColor: '#DF2020',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 8,
    flex: 1,
    marginRight: 8,
    alignItems: 'center',
    shadowColor: '#101010',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  cancelBtnText: {
    color: '#FFF',
    fontWeight: '600',
    fontSize: 16,
  },
  saveBtn: {
    backgroundColor: '#40BF4A',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 8,
    flex: 1,
    marginLeft: 8,
    alignItems: 'center',
    shadowColor: '#101010',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  saveBtnText: {
    color: '#FFF',
    fontWeight: '600',
    fontSize: 16,
  },
});

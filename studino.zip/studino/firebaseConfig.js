// firebaseConfig.js
import { initializeApp, getApps } from 'firebase/app';

const firebaseConfig = {
  apiKey: "AIzaSyC_HAz2XwoJlHmRf5Jx56EPHeIWvEVKyyQ",
  authDomain: "studino-65803.firebaseapp.com",
  projectId: "studino-65803",
  storageBucket: "studino-65803.appspot.com",  // poprawione
  messagingSenderId: "659440093765",
  appId: "1:659440093765:web:6ae98dbe70c354a415312c",
  measurementId: "G-P2E85LL5QV"
};

export const firebaseApp = getApps().length === 0
  ? initializeApp(firebaseConfig)
  : getApps()[0];

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ActivityIndicator,
  StyleSheet,
  Image,
  Alert,
} from 'react-native';
import { enableScreens } from 'react-native-screens';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { GoogleSignin } from '@react-native-google-signin/google-signin';
import NetInfo from '@react-native-community/netinfo';

import {
  getAuth,
  onAuthStateChanged,
  signOut,
} from '@react-native-firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  collection,
  query,
  where,
  getDocs,
  setDoc,
  updateDoc,
  serverTimestamp,
} from '@react-native-firebase/firestore';

import LoginScreen from './screens/LoginScreen';
import ProfileSetupScreen from './screens/ProfileSetupScreen';
import HomeScreen from './screens/HomeScreen';
import YourProfile from './screens/YourProfile';
import Settings from './screens/Settings';
import QuizSelectScreen from './screens/QuizSelectScreen';
import BrowseQuizesScreen from './screens/BrowseQuizesScreen';
import ManageQuizzesScreen from './screens/ManageQuizzesScreen';
import TitleSelectScreen from './screens/TitleSelectScreen';
import CreateQuizScreen from './screens/CreateQuizScreen';
import PublicProfileScreen from './screens/PublicProfileScreen';
import EnglishMinigameScreen from './screens/EnglishMinigameScreen';
import ChemistryMinigameScreen from './screens/ChemistryMinigameScreen';
import MathMinigameScreen from './screens/MathMinigameScreen';
import QuizDetailsScreen from './screens/QuizDetailsScreen';
import QuizGameScreen from './screens/QuizGameScreen';
import QuizResultsScreen from './screens/QuizResultsScreen';
import QuizHistoryScreen from './screens/QuizHistoryScreen';

enableScreens();
const Stack = createStackNavigator();

const avatarImages = {
  avatar1: require('./images/avatars/avatar1.png'),
  avatar2: require('./images/avatars/avatar2.png'),
  avatar3: require('./images/avatars/avatar3.png'),
  avatar4: require('./images/avatars/avatar4.png'),
  avatar5: require('./images/avatars/avatar5.png'),
  avatar6: require('./images/avatars/avatar6.png'),
  avatar7: require('./images/avatars/avatar7.png'),
  avatar8: require('./images/avatars/avatar8.png'),
  avatar9: require('./images/avatars/avatar9.png'),
  avatar10: require('./images/avatars/avatar10.png'),
  avatar11: require('./images/avatars/avatar11.png'),
  avatar12: require('./images/avatars/avatar12.png'),
};

export default function App() {
  const [authInitializing, setAuthInitializing] = useState(true);
  const [user, setUser] = useState(null);
  const [profileLoaded, setProfileLoaded] = useState(false);
  const [userProfile, setUserProfile] = useState(null);
  const [isConnected, setIsConnected] = useState(true);

  const auth = getAuth();
  const db = getFirestore();

  useEffect(() => {
    GoogleSignin.configure({
      webClientId:
        '659440093765-34pkg6r1o33vibp951pch1i0qj2hbm5d.apps.googleusercontent.com',
      offlineAccess: true,
      forceCodeForRefreshToken: true,
    });

    const unsubscribe = NetInfo.addEventListener(state => {
      setIsConnected(state.isConnected);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, firebaseUser => {
      setUser(firebaseUser);
      setProfileLoaded(false);
      setUserProfile(null);

      if (firebaseUser) {
        const userRef = doc(db, 'users', firebaseUser.uid);

        setDoc(
          userRef,
          { lastLoginAt: serverTimestamp() },
          { merge: true },
        ).catch(e => console.error('Error updating lastLogin:', e));

        getDoc(userRef)
          .then(snap => {
            const data = snap.exists() ? snap.data() : {};
            setUserProfile(data.username ? data : null);
          })
          .catch(e => {
            console.error('Error fetching userProfile:', e);
            setUserProfile(null);
          })
          .finally(() => {
            setProfileLoaded(true);
            if (authInitializing) setAuthInitializing(false);
          });
      } else {
        setProfileLoaded(true);
        if (authInitializing) setAuthInitializing(false);
      }
    });
    return () => unsubscribe();
  }, [authInitializing]);

  const handleLogout = async () => {
    try {
      setProfileLoaded(false);
      setUserProfile(null);

      if (await GoogleSignin.hasPreviousSignIn()) {
        await GoogleSignin.signOut();
      }
      await signOut(auth);
    } catch (e) {
      console.error('Logout error:', e);
      Alert.alert('Błąd', 'Nie udało się wylogować');
      setProfileLoaded(true);
    }
  };

  const checkUsernameAvailability = async username => {
    try {
      const uname = username.trim().toLowerCase();
      const q = query(collection(db, 'users'), where('username', '==', uname));
      const snap = await getDocs(q);
      return snap.empty;
    } catch (e) {
      console.error('Username check error:', e);
      return false;
    }
  };

  if (authInitializing || (user && !profileLoaded)) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#6495ED" />
        <Text style={styles.loadingText}>Ładowanie...</Text>
      </View>
    );
  }

  if (!isConnected) {
    return (
      <View style={styles.noConnectionContainer}>
        <Image
          source={require('./images/icons/logo.png')}
          style={styles.logo}
        />
        <Text style={styles.messageText}>Brak połączenia z internetem</Text>
        <Text style={styles.descriptionText}>
          Sprawdź swoje połączenie i spróbuj ponownie.
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.wrapper}>
      <NavigationContainer
        theme={{
          ...DarkTheme,
          colors: {
            ...DarkTheme.colors,
            background: '#202020',
            card: '#202020',
          },
        }}
      >
        <Stack.Navigator
          screenOptions={{
            headerShown: false,
            cardStyle: { backgroundColor: '#202020' },
          }}
        >
          {user ? (
            userProfile ? (
              <>
                <Stack.Screen name="HomeScreen">
                  {props => (
                    <HomeScreen
                      {...props}
                      user={user}
                      userProfile={userProfile}
                      onLogout={handleLogout}
                      avatarImages={avatarImages}
                    />
                  )}
                </Stack.Screen>

                <Stack.Screen name="BrowseQuizesScreen">
                  {props => (
                    <BrowseQuizesScreen
                      {...props}
                      user={user}
                      userProfile={userProfile}
                      onLogout={handleLogout}
                      onNavigateToQuiz={quiz =>
                        props.navigation.navigate('QuizDetailsScreen', { quiz })
                      }
                    />
                  )}
                </Stack.Screen>

                <Stack.Screen name="QuizDetailsScreen">
                  {props => (
                    <QuizDetailsScreen
                      quiz={props.route.params.quiz}
                      onBack={() => props.navigation.goBack()}
                      onStartQuiz={quiz =>
                        props.navigation.navigate('QuizGameScreen', { quiz })
                      }
                    />
                  )}
                </Stack.Screen>

                <Stack.Screen name="QuizGameScreen">
                  {props => (
                    <QuizGameScreen
                      quiz={props.route.params.quiz}
                      onQuizComplete={results =>
                        props.navigation.navigate('QuizResultsScreen', {
                          results,
                          quiz: props.route.params.quiz,
                        })
                      }
                      onBack={() => props.navigation.goBack()}
                    />
                  )}
                </Stack.Screen>

                <Stack.Screen name="QuizResultsScreen">
                  {props => (
                    <QuizResultsScreen
                      {...props}
                      results={props.route.params.results}
                      quiz={props.route.params.quiz}
                      userId={user.uid}
                      onBack={() =>
                        props.navigation.navigate('BrowseQuizesScreen')
                      }
                      onPlayAgain={() =>
                        props.navigation.navigate('QuizGameScreen', {
                          quiz: props.route.params.quiz,
                        })
                      }
                    />
                  )}
                </Stack.Screen>

                <Stack.Screen name="QuizSelectScreen">
                  {props => <QuizSelectScreen {...props} user={user} />}
                </Stack.Screen>

                <Stack.Screen name="QuizHistoryScreen">
                  {props => <QuizHistoryScreen {...props} user={user} />}
                </Stack.Screen>

                <Stack.Screen name="ManageQuizzesScreen">
                  {props => (
                    <ManageQuizzesScreen {...props} userUid={user?.uid} />
                  )}
                </Stack.Screen>

                <Stack.Screen name="TitleSelectScreen">
                  {props => (
                    <TitleSelectScreen
                      {...props}
                      user={user}
                      userStats={userProfile}
                    />
                  )}
                </Stack.Screen>

                <Stack.Screen name="CreateQuizScreen">
                  {props => (
                    <CreateQuizScreen
                      {...props}
                      user={user}
                      userProfile={userProfile}
                    />
                  )}
                </Stack.Screen>

                <Stack.Screen name="YourProfile">
                  {props => (
                    <YourProfile
                      {...props}
                      user={user}
                      userProfile={userProfile}
                      avatarImages={avatarImages}
                      onProfileUpdated={setUserProfile}
                      onLogout={handleLogout}
                    />
                  )}
                </Stack.Screen>

                <Stack.Screen name="Settings">
                  {props => (
                    <Settings
                      {...props}
                      user={user}
                      userProfile={userProfile}
                      onProfileUpdated={setUserProfile}
                      checkUsernameAvailability={checkUsernameAvailability}
                      onLogout={handleLogout}
                    />
                  )}
                </Stack.Screen>

                <Stack.Screen
                  name="PublicProfileScreen"
                  component={PublicProfileScreen}
                />
                <Stack.Screen
                  name="EnglishMinigameScreen"
                  component={EnglishMinigameScreen}
                />
                <Stack.Screen
                  name="ChemistryMinigameScreen"
                  component={ChemistryMinigameScreen}
                />
                <Stack.Screen
                  name="MathMinigameScreen"
                  component={MathMinigameScreen}
                />
              </>
            ) : (
              <Stack.Screen name="ProfileSetup">
                {props => (
                  <ProfileSetupScreen
                    {...props}
                    user={user}
                    avatarImages={avatarImages}
                    checkUsernameAvailability={checkUsernameAvailability}
                    onProfileCreated={setUserProfile}
                  />
                )}
              </Stack.Screen>
            )
          ) : (
            <Stack.Screen name="Login" component={LoginScreen} />
          )}
        </Stack.Navigator>
      </NavigationContainer>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flex: 1,
    backgroundColor: '#202020',
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: '#202020',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#CCC',
    marginTop: 10,
    fontSize: 16,
  },
  noConnectionContainer: {
    flex: 1,
    backgroundColor: '#202020',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  logo: {
    width: 150,
    height: 150,
    marginBottom: 20,
  },
  messageText: {
    color: '#FFEB3B',
    fontSize: 18,
    fontWeight: 'bold',
  },
  descriptionText: {
    color: '#FFF',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 10,
  },
});

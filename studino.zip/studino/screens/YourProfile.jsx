import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  ScrollView,
  StyleSheet,
  Modal,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRoute } from '@react-navigation/native';
import {
  getFirestore,
  doc,
  onSnapshot,
  updateDoc,
} from '@react-native-firebase/firestore';
import auth from '@react-native-firebase/auth';

export default function YourProfile({
  navigation,
  user,
  avatarImages,
  onLogout,
}) {
  const route = useRoute();
  const currentRoute = route.name;

  const [profile, setProfile] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedAvatar, setSelectedAvatar] = useState(null);

  const db = getFirestore();

  useEffect(() => {
    const userRef = doc(db, 'users', user.uid);
    const unsub = onSnapshot(
      userRef,
      snap => {
        if (snap.exists()) {
          const data = snap.data();
          setProfile(data);
          setSelectedAvatar(data.avatar);
        } else {
          setProfile(null);
        }
      },
      err => {
        console.error('Firestore onSnapshot error:', err);
        setProfile(null);
      },
    );
    return () => unsub();
  }, [db, user.uid]);

  if (!profile) {
    return (
      <View style={styles.center}>
        <Text style={styles.loading}>Ładowanie...</Text>
      </View>
    );
  }

  const formatDate = ts => {
    if (!ts?.toDate) return '—';
    return ts.toDate().toLocaleDateString('pl-PL', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      timeZone: 'Europe/Warsaw',
    });
  };

  const {
    username,
    createdAt,
    currentStreak = 0,
    longestStreak = 0,
    favorites = [],
    liked_quizzes = [],
    quizzesCreated = 0,
    quizzesPlayed = 0,
    totalPercentage = 0,
    totalQuizTime = 0,
    totalQuestionsAnswered = 1,
    englishFlashcardsCorrect = 0,
    englishFlashcardsAnswered = 1,
    mathCorrect = 0,
    mathAnswered = 1,
    chemistryCorrect = 0,
    chemistryAnswered = 1,
    selectedTitle,
    titlesCount = 0,
  } = profile;

  const accountDateStr = formatDate(createdAt);
  const avgPercent = quizzesPlayed
    ? (totalPercentage / quizzesPlayed).toFixed(1)
    : '0.0';
  const avgTimePerQ = ((totalQuizTime / totalQuestionsAnswered) * 60).toFixed(
    2,
  );

  const changeAvatar = async key => {
    try {
      const userRef = doc(db, 'users', user.uid);
      await updateDoc(userRef, { avatar: key });
      setModalVisible(false);
    } catch {
      Alert.alert('Błąd', 'Nie udało się zmienić avatara');
    }
  };

  return (
    <SafeAreaView style={styles.wrapper}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.username}>{username}</Text>

        <View style={styles.avatarContainer}>
          <TouchableOpacity
            style={styles.avatarTouchable}
            onPress={() => setModalVisible(true)}
            activeOpacity={0.8}
          >
            <Image
              source={avatarImages[selectedAvatar]}
              style={styles.avatar}
            />
            <View style={styles.editAvatarOverlay}>
              <Text style={styles.editAvatarIcon}>✏️</Text>
            </View>
          </TouchableOpacity>
          <Text style={styles.avatarHint}>Dotknij, aby zmienić avatar</Text>
        </View>

        <View style={styles.titleContainer}>
          <TouchableOpacity
            style={styles.titleButton}
            onPress={() => navigation.navigate('TitleSelectScreen')}
            activeOpacity={0.7}
          >
            <View style={styles.titleContent}>
              <Text style={styles.titleLabel}>🏅 Tytuł:</Text>
              <Text style={styles.titleValue}>
                {selectedTitle || 'Brak wybranego tytułu'}
              </Text>
              <Text style={styles.titleArrow}>→</Text>
            </View>
            <Text style={styles.titleHint}>Dotknij, aby zmienić tytuł</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.logoutBtn} onPress={onLogout}>
          <Text style={styles.logoutText}>Wyloguj się</Text>
        </TouchableOpacity>

        <View style={styles.statsContainer}>
          <Text style={styles.sectionHeader}>📊 Ogólne i quizy</Text>
          <View style={styles.statsGrid}>
            {[
              ['Data utworzenia:', accountDateStr],
              ['Aktualna seria:', currentStreak],
              ['Najdłuższa seria:', longestStreak],
              ['Ulubione quizy:', favorites.length],
              ['Polubione quizy:', liked_quizzes.length],
              ['Utworzone quizy:', quizzesCreated],
              ['Rozegrane quizy:', quizzesPlayed],
              ['Śr. wynik quizów:', `${avgPercent}%`],
              ['Cał. czas w quizach:', `${(totalQuizTime / 60).toFixed(1)}h`],
              ['Śr. czas/pyt:', `${isNaN(avgTimePerQ) ? 0 : avgTimePerQ}s`],
              ['Posiadane tytuły:', titlesCount],
            ].map(([label, value], i) => (
              <View key={i} style={styles.statCard}>
                <Text style={styles.statLabel}>{label}</Text>
                <Text style={styles.statValue}>{value}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={styles.statsContainer}>
          <Text style={styles.sectionHeader}>🎮 Minigry</Text>
          <View style={styles.statsGrid}>
            {[
              [
                'Angielski:',
                `${(
                  (englishFlashcardsCorrect / englishFlashcardsAnswered) *
                  100
                ).toFixed(1)}%`,
              ],
              [
                'Matematyka:',
                `${((mathCorrect / mathAnswered) * 100).toFixed(1)}%`,
              ],
              [
                'Chemia:',
                `${((chemistryCorrect / chemistryAnswered) * 100).toFixed(1)}%`,
              ],
            ].map(([label, value], i) => (
              <View key={i} style={styles.statCard}>
                <Text style={styles.statLabel}>{label}</Text>
                <Text style={styles.statValue}>{value}</Text>
              </View>
            ))}
          </View>
        </View>
      </ScrollView>

      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>✨ Wybierz avatar</Text>
            <ScrollView contentContainerStyle={styles.avatarsContainer}>
              {Object.entries(avatarImages).map(([key, src]) => (
                <TouchableOpacity
                  key={key}
                  style={[
                    styles.avatarOption,
                    selectedAvatar === key && styles.avatarOptionSelected,
                  ]}
                  onPress={() => changeAvatar(key)}
                  activeOpacity={0.7}
                >
                  <Image source={src} style={styles.avatarImage} />
                  {selectedAvatar === key && (
                    <View style={styles.selectedIndicator}>
                      <Text style={styles.selectedIcon}>✓</Text>
                    </View>
                  )}
                </TouchableOpacity>
              ))}
            </ScrollView>
            <TouchableOpacity
              style={styles.modalClose}
              onPress={() => setModalVisible(false)}
            >
              <Text style={styles.modalCloseText}>Zamknij</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <View style={styles.bottomNavigation}>
        <TouchableOpacity
          style={[
            styles.navButton,
            currentRoute === 'HomeScreen' && styles.activeNavButton,
          ]}
          onPress={() => navigation.navigate('HomeScreen')}
        >
          <Text style={styles.navEmoji}>🏠</Text>
          <Text style={styles.navLabel}>Główna</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.navButton,
            currentRoute === 'QuizSelectScreen' && styles.activeNavButton,
          ]}
          onPress={() => navigation.navigate('QuizSelectScreen')}
        >
          <Text style={styles.navEmoji}>🎯</Text>
          <Text style={styles.navLabel}>Quizy</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.navButton,
            currentRoute === 'YourProfile' && styles.activeNavButton,
          ]}
          onPress={() => navigation.navigate('YourProfile')}
        >
          <Text style={styles.navEmoji}>👤</Text>
          <Text style={styles.navLabel}>Profil</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.navButton,
            currentRoute === 'TitleSelectScreen' && styles.activeNavButton,
          ]}
          onPress={() => navigation.navigate('TitleSelectScreen')}
        >
          <Text style={styles.navEmoji}>🏅</Text>
          <Text style={styles.navLabel}>Tytuły</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.navButton,
            currentRoute === 'Settings' && styles.activeNavButton,
          ]}
          onPress={() => navigation.navigate('Settings')}
        >
          <Text style={styles.navEmoji}>⚙️</Text>
          <Text style={styles.navLabel}>Ustawienia</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  wrapper: { flex: 1, backgroundColor: '#1a1a1a' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loading: { color: '#FFF', fontSize: 16 },
  container: { padding: 20, paddingBottom: 100 },

  username: {
    fontSize: 32,
    color: '#FFF',
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },

  avatarContainer: { alignItems: 'center', marginVertical: 20 },
  avatarTouchable: {
    position: 'relative',
    shadowColor: '#6495ED',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  avatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
    borderWidth: 4,
    borderColor: '#6495ED',
  },
  editAvatarOverlay: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: '#6495ED',
    borderRadius: 15,
    width: 30,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#1a1a1a',
  },
  editAvatarIcon: { fontSize: 12, color: '#FFF' },
  avatarHint: {
    color: '#888',
    fontSize: 12,
    marginTop: 8,
    fontStyle: 'italic',
  },

  titleContainer: { marginVertical: 15 },
  titleButton: {
    backgroundColor: '#2d2d2d',
    borderRadius: 12,
    padding: 16,
    borderWidth: 2,
    borderColor: '#444',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  titleContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  titleLabel: { color: '#CCC', fontSize: 16, fontWeight: '600' },
  titleValue: {
    color: '#FFF',
    fontWeight: 'bold',
    fontSize: 16,
    flex: 1,
    textAlign: 'center',
  },
  titleArrow: { color: '#6495ED', fontSize: 18, fontWeight: 'bold' },
  titleHint: {
    color: '#888',
    fontSize: 11,
    marginTop: 6,
    textAlign: 'center',
    fontStyle: 'italic',
  },

  logoutBtn: {
    backgroundColor: '#DF2020',
    padding: 14,
    borderRadius: 10,
    alignSelf: 'center',
    marginVertical: 20,
    shadowColor: '#DF2020',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  logoutText: { color: '#FFF', fontWeight: 'bold', fontSize: 16 },

  statsContainer: { marginVertical: 10 },
  sectionHeader: {
    color: '#FFF',
    fontSize: 22,
    marginBottom: 15,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  statsGrid: { gap: 8 },
  statCard: {
    backgroundColor: '#2d2d2d',
    padding: 12,
    borderRadius: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderLeftWidth: 4,
    borderLeftColor: '#6495ED',
  },
  statLabel: { color: '#CCC', fontSize: 14, flex: 1 },
  statValue: { color: '#FFF', fontWeight: 'bold', fontSize: 16 },

  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '85%',
    backgroundColor: '#2d2d2d',
    borderRadius: 16,
    padding: 24,
    paddingBottom: 60,
    borderWidth: 2,
    borderColor: '#444',
  },
  modalTitle: {
    color: '#FFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  avatarsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: 12,
  },
  avatarOption: {
    margin: 4,
    padding: 4,
    borderRadius: 40,
    borderWidth: 3,
    borderColor: 'transparent',
    position: 'relative',
  },
  avatarOptionSelected: {
    borderColor: '#6495ED',
    backgroundColor: 'rgba(100, 149, 237, 0.1)',
  },
  avatarImage: { width: 60, height: 60, borderRadius: 30 },
  selectedIndicator: {
    position: 'absolute',
    top: -2,
    right: -2,
    backgroundColor: '#6495ED',
    borderRadius: 10,
    width: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedIcon: { color: '#FFF', fontSize: 12, fontWeight: 'bold' },
  modalClose: {
    marginTop: 20,
    alignSelf: 'center',
    padding: 12,
    backgroundColor: '#6495ED',
    borderRadius: 8,
    minWidth: 100,
  },
  modalCloseText: {
    color: '#FFF',
    textAlign: 'center',
    fontWeight: 'bold',
  },

  bottomNavigation: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    backgroundColor: '#2d2d2d',
    paddingVertical: 12,
    borderTopWidth: 1,
    borderTopColor: '#444',
  },
  navButton: { flex: 1, alignItems: 'center', paddingVertical: 4 },
  activeNavButton: {
    backgroundColor: '#374151',
    borderRadius: 8,
    marginHorizontal: 4,
  },
  navEmoji: { fontSize: 20 },
  navLabel: { color: '#CCC', fontSize: 10, marginTop: 2 },
});

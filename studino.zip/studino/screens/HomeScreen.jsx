import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  TouchableWithoutFeedback,
  StyleSheet,
  Image,
  ScrollView,
  SafeAreaView,
  Modal,
  Animated,
  Easing,
} from 'react-native';
import {
  getFirestore,
  doc,
  onSnapshot,
} from '@react-native-firebase/firestore';
import { useRoute } from '@react-navigation/native';

const avatarImages = {
  avatar1: require('../images/avatars/avatar1.png'),
  avatar2: require('../images/avatars/avatar2.png'),
  avatar3: require('../images/avatars/avatar3.png'),
  avatar4: require('../images/avatars/avatar4.png'),
  avatar5: require('../images/avatars/avatar5.png'),
  avatar6: require('../images/avatars/avatar6.png'),
  avatar7: require('../images/avatars/avatar7.png'),
  avatar8: require('../images/avatars/avatar8.png'),
  avatar9: require('../images/avatars/avatar9.png'),
  avatar10: require('../images/avatars/avatar10.png'),
  avatar11: require('../images/avatars/avatar11.png'),
  avatar12: require('../images/avatars/avatar12.png'),
};

export default function HomeScreen({ user, onLogout, navigation }) {
  const route = useRoute();
  const currentRoute = route.name;

  const [profile, setProfile] = useState(null);
  const [isMathModalVisible, setMathModalVisible] = useState(false);
  const [isEngModalVisible, setEngModalVisible] = useState(false);
  const [isChemModalVisible, setChemModalVisible] = useState(false);
  const [animScale] = useState(new Animated.Value(0.8));

  const db = getFirestore();

  useEffect(() => {
    const userDoc = doc(db, 'users', user.uid);
    const unsubscribe = onSnapshot(
      userDoc,
      snap => {
        if (snap.exists()) {
          setProfile(snap.data());
        } else {
          setProfile(null);
        }
      },
      error => {
        console.error('Firestore onSnapshot error:', error);
        setProfile(null);
      },
    );
    return () => unsubscribe();
  }, [db, user.uid]);

  if (!profile) {
    return (
      <View style={styles.center}>
        <Text style={styles.loading}>Ładowanie...</Text>
      </View>
    );
  }

  const {
    avatar,
    username,
    currentStreak = 0,
    totalPercentage = 0,
    quizzesPlayed = 0,
    totalQuizTime = 0,
    totalQuestionsAnswered = 1,
    mathCorrect = 0,
    mathAnswered = 1,
    englishFlashcardsCorrect = 0,
    englishFlashcardsAnswered = 1,
    chemistryCorrect = 0,
    chemistryAnswered = 1,
  } = profile;

  const avgQuizScore =
    quizzesPlayed > 0 ? (totalPercentage / quizzesPlayed).toFixed(1) : '0.0';
  const avgTimePerQ = ((totalQuizTime / totalQuestionsAnswered) * 60).toFixed(
    2,
  );
  const mathAcc = ((mathCorrect / mathAnswered) * 100).toFixed(1);
  const engAcc = (
    (englishFlashcardsCorrect / englishFlashcardsAnswered) *
    100
  ).toFixed(1);
  const chemAcc = ((chemistryCorrect / chemistryAnswered) * 100).toFixed(1);

  const openModal = setter => {
    setter(true);
    animScale.setValue(0.8);
    Animated.timing(animScale, {
      toValue: 1,
      duration: 200,
      easing: Easing.out(Easing.ease),
      useNativeDriver: true,
    }).start();
  };
  const closeModal = setter => setter(false);

  const openMathModal = () => openModal(setMathModalVisible);
  const closeMathModal = () => closeModal(setMathModalVisible);
  const selectMathMode = mode => {
    closeMathModal();
    navigation.navigate('MathMinigameScreen', { mode });
  };

  const openEngModal = () => openModal(setEngModalVisible);
  const closeEngModal = () => closeModal(setEngModalVisible);
  const selectEngDirection = dir => {
    closeEngModal();
    navigation.navigate('EnglishMinigameScreen', { direction: dir });
  };

  const openChemModal = () => openModal(setChemModalVisible);
  const closeChemModal = () => closeModal(setChemModalVisible);
  const selectChemMode = mode => {
    closeChemModal();
    navigation.navigate('ChemistryMinigameScreen', { mode });
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.header}>
          <Image
            source={avatarImages[avatar] || avatarImages.avatar1}
            style={styles.profileAvatar}
          />
          <View style={styles.welcomeSection}>
            <Text style={styles.welcomeText}>Cześć!</Text>
            <Text style={styles.usernameText}>{username}</Text>
          </View>
        </View>

        <TouchableOpacity
          style={[styles.menuCard, styles.primaryCard]}
          onPress={() => navigation.navigate('QuizSelectScreen')}
        >
          <Text style={styles.menuEmoji}>🎯</Text>
          <Text style={styles.menuTitle}>Quizy</Text>
          <Text style={styles.menuDescription}>
            Sprawdź swoją wiedzę w różnych kategoriach
          </Text>
        </TouchableOpacity>

        <View style={styles.minigamesSection}>
          <Text style={styles.sectionTitle}>🎮 Minigry</Text>
          <View style={styles.minigamesRow}>
            <TouchableOpacity
              style={[styles.minigameCard, styles.mathCard]}
              onPress={openMathModal}
            >
              <Text style={styles.minigameEmoji}>🧮</Text>
              <Text style={styles.minigameTitle}>Matematyka</Text>
              <Text style={styles.minigameDesc}>Szybkie liczenie</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.minigameCard, styles.englishCard]}
              onPress={openEngModal}
            >
              <Text style={styles.minigameEmoji}>🇬🇧</Text>
              <Text style={styles.minigameTitle}>Angielski</Text>
              <Text style={styles.minigameDesc}>Słownictwo</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.minigameCard, styles.chemistryCard]}
              onPress={openChemModal}
            >
              <Text style={styles.minigameEmoji}>🧪</Text>
              <Text style={styles.minigameTitle}>Chemia</Text>
              <Text style={styles.minigameDesc}>Pierwiastki</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.statsSection}>
          <Text style={styles.sectionTitle}>🏆 Twoje Osiągnięcia</Text>
          <View style={styles.statsGrid}>
            {[
              { num: currentStreak, label: 'Aktualna seria' },
              { num: `${avgQuizScore}%`, label: 'Śr. wynik quizów' },
              {
                num: `${isNaN(avgTimePerQ) ? '0.00' : avgTimePerQ}s`,
                label: 'Śr. czas/pyt.',
              },
              { num: `${mathAcc}%`, label: 'Minigra - matematyka' },
              { num: `${engAcc}%`, label: 'Minigra - angielski' },
              { num: `${chemAcc}%`, label: 'Minigra - chemia' },
            ].map((s, i) => (
              <View key={i} style={styles.statCard}>
                <Text style={styles.statNumber}>{s.num}</Text>
                <Text style={styles.statLabel}>{s.label}</Text>
              </View>
            ))}
          </View>
        </View>
      </ScrollView>

      <Modal
        transparent
        visible={isMathModalVisible}
        onRequestClose={closeMathModal}
      >
        <TouchableWithoutFeedback onPress={closeMathModal}>
          <View style={styles.modalOverlay}>
            <TouchableWithoutFeedback>
              <Animated.View
                style={[
                  styles.modalContent,
                  { transform: [{ scale: animScale }] },
                ]}
              >
                <Text style={styles.modalTitle}>Wybierz poziom:</Text>
                <TouchableOpacity
                  style={styles.modalButton}
                  onPress={() => selectMathMode('simple')}
                >
                  <Text style={styles.modalButtonText}>Zwykłe działania</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.modalButton}
                  onPress={() => selectMathMode('advanced')}
                >
                  <Text style={styles.modalButtonText}>
                    Trudniejsze działania
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.modalButton, styles.cancelButton]}
                  onPress={closeMathModal}
                >
                  <Text style={styles.cancelText}>Anuluj</Text>
                </TouchableOpacity>
              </Animated.View>
            </TouchableWithoutFeedback>
          </View>
        </TouchableWithoutFeedback>
      </Modal>

      <Modal
        transparent
        visible={isEngModalVisible}
        onRequestClose={closeEngModal}
      >
        <TouchableWithoutFeedback onPress={closeEngModal}>
          <View style={styles.modalOverlay}>
            <TouchableWithoutFeedback>
              <Animated.View
                style={[
                  styles.modalContent,
                  { transform: [{ scale: animScale }] },
                ]}
              >
                <Text style={styles.modalTitle}>Wybierz kierunek:</Text>
                <TouchableOpacity
                  style={styles.modalButton}
                  onPress={() => selectEngDirection('eng2pl')}
                >
                  <Text style={styles.modalButtonText}>ANG → PL</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.modalButton}
                  onPress={() => selectEngDirection('pl2eng')}
                >
                  <Text style={styles.modalButtonText}>PL → ANG</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.modalButton, styles.cancelButton]}
                  onPress={closeEngModal}
                >
                  <Text style={styles.cancelText}>Anuluj</Text>
                </TouchableOpacity>
              </Animated.View>
            </TouchableWithoutFeedback>
          </View>
        </TouchableWithoutFeedback>
      </Modal>

      <Modal
        transparent
        visible={isChemModalVisible}
        onRequestClose={closeChemModal}
      >
        <TouchableWithoutFeedback onPress={closeChemModal}>
          <View style={styles.modalOverlay}>
            <TouchableWithoutFeedback>
              <Animated.View
                style={[
                  styles.modalContent,
                  { transform: [{ scale: animScale }] },
                ]}
              >
                <Text style={styles.modalTitle}>Wybierz tryb chemii:</Text>
                {[
                  { key: 'name2symbol', label: 'Nazwa → Symbol' },
                  { key: 'name2atomicNumber', label: 'Nazwa → Liczba atomowa' },
                  { key: 'name2atomicMass', label: 'Nazwa → Masa atomowa' },
                  { key: 'atomicNumber2name', label: 'Liczba atomowa → Nazwa' },
                  { key: 'symbol2name', label: 'Symbol → Nazwa' },
                  { key: 'atomicMass2name', label: 'Masa atomowa → Nazwa' },
                ].map(item => (
                  <TouchableOpacity
                    key={item.key}
                    style={styles.modalButton}
                    onPress={() => selectChemMode(item.key)}
                  >
                    <Text style={styles.modalButtonText}>{item.label}</Text>
                  </TouchableOpacity>
                ))}
                <TouchableOpacity
                  style={[styles.modalButton, styles.cancelButton]}
                  onPress={closeChemModal}
                >
                  <Text style={styles.cancelText}>Anuluj</Text>
                </TouchableOpacity>
              </Animated.View>
            </TouchableWithoutFeedback>
          </View>
        </TouchableWithoutFeedback>
      </Modal>

      <View style={styles.bottomNavigation}>
        <TouchableOpacity
          style={[
            styles.navButton,
            currentRoute === 'HomeScreen' && styles.activeNavButton,
          ]}
          onPress={() => navigation.navigate('HomeScreen')}
        >
          <Text style={styles.navEmoji}>🏠</Text>
          <Text style={styles.navLabel}>Główna</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.navButton,
            currentRoute === 'QuizSelectScreen' && styles.activeNavButton,
          ]}
          onPress={() => navigation.navigate('QuizSelectScreen')}
        >
          <Text style={styles.navEmoji}>🎯</Text>
          <Text style={styles.navLabel}>Quizy</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.navButton,
            currentRoute === 'YourProfile' && styles.activeNavButton,
          ]}
          onPress={() => navigation.navigate('YourProfile')}
        >
          <Text style={styles.navEmoji}>👤</Text>
          <Text style={styles.navLabel}>Profil</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.navButton,
            currentRoute === 'TitleSelectScreen' && styles.activeNavButton,
          ]}
          onPress={() => navigation.navigate('TitleSelectScreen')}
        >
          <Text style={styles.navEmoji}>🏅</Text>
          <Text style={styles.navLabel}>Tytuły</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.navButton,
            currentRoute === 'Settings' && styles.activeNavButton,
          ]}
          onPress={() => navigation.navigate('Settings')}
        >
          <Text style={styles.navEmoji}>⚙️</Text>
          <Text style={styles.navLabel}>Ustawienia</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1a1a1a',
  },
  scrollContainer: {
    padding: 20,
    paddingBottom: 70,
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loading: {
    color: '#FFF',
    fontSize: 16,
  },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  profileAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    borderWidth: 2,
    borderColor: '#6495ED',
  },
  welcomeSection: { flex: 1, marginLeft: 15 },
  welcomeText: { color: '#999', fontSize: 16 },
  usernameText: { color: '#FFF', fontSize: 24, fontWeight: 'bold' },
  logoutButton: { padding: 8 },
  logoutButtonText: { color: '#FFF', fontSize: 18 },

  menuCard: {
    backgroundColor: '#2d2d2d',
    padding: 20,
    borderRadius: 15,
    marginBottom: 20,
    alignItems: 'center',
    elevation: 4,
  },
  primaryCard: { backgroundColor: '#3d4ed8' },
  menuEmoji: { fontSize: 28, marginBottom: 8 },
  menuTitle: { color: '#FFF', fontSize: 18, fontWeight: 'bold' },
  menuDescription: { color: '#DDD', fontSize: 12, textAlign: 'center' },

  minigamesSection: { marginBottom: 25 },
  sectionTitle: {
    color: '#FFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  minigamesRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  minigameCard: {
    width: '48%',
    padding: 20,
    borderRadius: 15,
    alignItems: 'center',
    marginBottom: 15,
    elevation: 6,
  },
  mathCard: { backgroundColor: '#dc2626' },
  englishCard: { backgroundColor: '#8b5cf6' },
  chemistryCard: { backgroundColor: '#10b981' },
  minigameEmoji: { fontSize: 32, marginBottom: 8 },
  minigameTitle: { color: '#FFF', fontSize: 16, fontWeight: '700' },
  minigameDesc: { color: '#E5E5E5', fontSize: 12, textAlign: 'center' },

  statsSection: { marginBottom: 30 },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  statCard: {
    backgroundColor: '#2d2d2d',
    width: '48%',
    padding: 15,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 10,
    elevation: 3,
  },
  statNumber: {
    color: '#6495ED',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  statLabel: { color: '#CCC', fontSize: 12, textAlign: 'center' },

  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    width: '100%',
    backgroundColor: '#252525',
    borderRadius: 20,
    padding: 25,
    alignItems: 'center',
  },
  modalTitle: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 20,
  },
  modalButton: {
    backgroundColor: '#3b82f6',
    paddingVertical: 14,
    paddingHorizontal: 30,
    borderRadius: 12,
    marginBottom: 12,
    width: '100%',
    alignItems: 'center',
    elevation: 4,
  },
  modalButtonText: { color: '#FFF', fontSize: 16, fontWeight: '600' },
  cancelButton: { backgroundColor: '#374151' },
  cancelText: { color: '#AAA', fontSize: 14 },

  bottomNavigation: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    backgroundColor: '#2d2d2d',
    paddingVertical: 12,
    borderTopWidth: 1,
    borderTopColor: '#444',
  },
  navButton: { flex: 1, alignItems: 'center', paddingVertical: 4 },
  activeNavButton: {
    backgroundColor: '#374151',
    borderRadius: 8,
    marginHorizontal: 4,
  },
  navEmoji: { fontSize: 20 },
  navLabel: { color: '#CCC', fontSize: 10, marginTop: 2 },
});

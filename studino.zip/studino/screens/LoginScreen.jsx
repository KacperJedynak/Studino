import React, { useState } from 'react';
import {
  ScrollView,
  Text,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  StyleSheet,
  View,
} from 'react-native';
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  fetchSignInMethodsForEmail,
  sendPasswordResetEmail,
  GoogleAuthProvider,
  signInWithCredential,
} from '@react-native-firebase/auth';
import { getApp } from '@react-native-firebase/app';
import { GoogleSignin } from '@react-native-google-signin/google-signin';

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  const app = getApp();
  const auth = getAuth(app);

  const isValidEmail = e => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);

  const checkEmailAvailability = async e => {
    try {
      const methods = await fetchSignInMethodsForEmail(auth, e);
      return methods.length === 0;
    } catch {
      return false;
    }
  };

  const handleEmailAuth = async () => {
    setMessage('');
    const e = email.trim().toLowerCase();
    const p = password;

    if (!e || (isRegistering && !p)) {
      setMessage('Wypełnij wszystkie pola');
      return;
    }
    if (!isValidEmail(e)) {
      setMessage('Podaj prawidłowy adres email');
      return;
    }
    if (isRegistering && p.length < 6) {
      setMessage('Hasło musi mieć co najmniej 6 znaków');
      return;
    }
    if (p.length < 6) {
      setMessage('Hasło musi mieć co najmniej 6 znaków');
      return;
    }

    setLoading(true);
    try {
      if (isRegistering) {
        const available = await checkEmailAvailability(e);
        if (!available) {
          setMessage('Ten email jest już w użyciu. Zaloguj się.');
        } else {
          await createUserWithEmailAndPassword(auth, e, p);
          setMessage('Zarejestrowano pomyślnie!');
        }
      } else {
        await signInWithEmailAndPassword(auth, e, p);
        setMessage('Zalogowano pomyślnie!');
      }
    } catch (error) {
      switch (error.code) {
        case 'auth/email-already-in-use':
          setMessage('Ten email jest już w użyciu. Zaloguj się.');
          setIsRegistering(false);
          break;
        case 'auth/user-not-found':
          setMessage('Nie znaleziono konta. Zarejestruj się.');
          setIsRegistering(true);
          break;
        case 'auth/wrong-password':
        case 'auth/invalid-credential':
          setMessage('Nieprawidłowe dane logowania');
          break;
        case 'auth/invalid-email':
          setMessage('Nieprawidłowy format email');
          break;
        case 'auth/too-many-requests':
          setMessage('Za dużo prób logowania. Spróbuj ponownie później');
          break;
        case 'auth/weak-password':
          setMessage('Hasło jest za słabe');
          break;
        default:
          setMessage(error.message || 'Wystąpił nieoczekiwany błąd');
      }
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordReset = async () => {
    setMessage('');
    const e = email.trim().toLowerCase();
    if (!e) {
      setMessage('Podaj email, aby zresetować hasło');
      return;
    }
    if (!isValidEmail(e)) {
      setMessage('Podaj prawidłowy adres email');
      return;
    }
    setLoading(true);
    try {
      await sendPasswordResetEmail(auth, e);
      setMessage('Link do resetowania hasła wysłany na email');
    } catch {
      setMessage('Nie udało się wysłać linku, spróbuj ponownie');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setMessage('');
    setLoading(true);
    try {
      await GoogleSignin.hasPlayServices({
        showPlayServicesUpdateDialog: true,
      });
      await GoogleSignin.signOut();
      const userInfo = await GoogleSignin.signIn();

      const idToken = userInfo.idToken || userInfo?.data?.idToken;

      if (!idToken) throw new Error('Brak tokenu Google');

      const googleCredential = GoogleAuthProvider.credential(idToken);
      await signInWithCredential(auth, googleCredential);

      setMessage('Zalogowano przez Google!');
    } catch (error) {
      console.log('Google login error:', error);
      setMessage('Błąd logowania przez Google');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>
        {isRegistering ? 'Rejestracja' : 'Logowanie'}
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Email"
        placeholderTextColor="#999"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
      />

      <TextInput
        style={styles.input}
        placeholder="Hasło"
        placeholderTextColor="#999"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
        autoCapitalize="none"
      />

      <TouchableOpacity
        style={[styles.button, loading && styles.buttonDisabled]}
        onPress={handleEmailAuth}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator color="#FFF" />
        ) : (
          <Text style={styles.buttonText}>
            {isRegistering ? 'Zarejestruj się' : 'Zaloguj się'}
          </Text>
        )}
      </TouchableOpacity>

      {!!message && <Text style={styles.messageText}>{message}</Text>}

      <TouchableOpacity
        style={styles.switchButton}
        onPress={() => {
          setIsRegistering(!isRegistering);
          setMessage('');
        }}
        disabled={loading}
      >
        <Text style={styles.switchButtonText}>
          {isRegistering
            ? 'Masz już konto? Zaloguj się'
            : 'Nie masz konta? Zarejestruj się'}
        </Text>
      </TouchableOpacity>

      {!isRegistering && (
        <TouchableOpacity
          style={styles.switchButton}
          onPress={handlePasswordReset}
          disabled={loading}
        >
          <Text style={styles.switchButtonText}>Zapomniałeś hasła?</Text>
        </TouchableOpacity>
      )}

      <View style={styles.divider}>
        <View style={styles.dividerLine} />
        <Text style={styles.dividerText}>lub</Text>
        <View style={styles.dividerLine} />
      </View>

      <TouchableOpacity
        style={[styles.googleButton, loading && styles.buttonDisabled]}
        onPress={handleGoogleLogin}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator color="#FFF" />
        ) : (
          <Text style={styles.buttonText}>Zaloguj przez Google</Text>
        )}
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#202020',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 28,
    color: '#6495ED',
    fontWeight: 'bold',
    marginBottom: 30,
  },
  input: {
    backgroundColor: '#404040',
    color: '#FFF',
    width: '100%',
    padding: 15,
    marginVertical: 8,
    borderRadius: 10,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#555',
  },
  button: {
    backgroundColor: '#6495ED',
    width: '100%',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  buttonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  messageText: {
    color: '#FFEB3B',
    fontSize: 16,
    marginVertical: 10,
    textAlign: 'center',
  },
  switchButton: {
    marginVertical: 15,
  },
  switchButtonText: {
    color: '#6495ED',
    textDecorationLine: 'underline',
    fontSize: 14,
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 20,
    width: '100%',
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#555',
  },
  dividerText: {
    color: '#999',
    marginHorizontal: 15,
    fontSize: 14,
  },
  googleButton: {
    backgroundColor: '#DB4437',
    width: '100%',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
});

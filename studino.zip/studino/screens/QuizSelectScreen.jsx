import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Image,
  Dimensions,
  ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRoute } from '@react-navigation/native';

const { width } = Dimensions.get('window');

export default function QuizSelectScreen({ navigation, user }) {
  const route = useRoute();
  const currentRoute = route.name;

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.cardScroll}>
        <View style={styles.cardContainer}>
          <TouchableOpacity
            style={[styles.card, styles.createCard]}
            onPress={() => navigation.navigate('CreateQuizScreen')}
          >
            <Image
              style={styles.icon}
              source={require('../images/icons/plus.png')}
            />
            <Text style={styles.title}>Stwórz Quiz</Text>
            <Text style={styles.subtitle}>Dodaj nowe quizy</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.card, styles.searchCard]}
            onPress={() => navigation.navigate('BrowseQuizesScreen')}
          >
            <Image
              style={styles.icon}
              source={require('../images/icons/search-large.png')}
            />
            <Text style={styles.title}>Szukaj Quizu</Text>
            <Text style={styles.subtitle}>Przeglądaj dostępne quizy</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.card, styles.manageCard]}
            onPress={() =>
              navigation.navigate('ManageQuizzesScreen', { userUid: user.uid })
            }
          >
            <Image
              style={styles.icon}
              source={require('../images/icons/Cog.png')}
            />
            <Text style={styles.title}>Zarządzaj Quizami</Text>
            <Text style={styles.subtitle}>Edytuj i usuwaj quizy</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.card, styles.historyCard]}
            onPress={() => navigation.navigate('QuizHistoryScreen')}
          >
            <Image
              style={styles.icon}
              source={require('../images/icons/History.png')}
            />
            <Text style={styles.title}>Historia Quizów</Text>
            <Text style={styles.subtitle}>
              Zobacz swoje poprzednie rozgrywki
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      <View style={styles.bottomNavigation}>
        <TouchableOpacity
          style={[
            styles.navButton,
            currentRoute === 'HomeScreen' && styles.activeNavButton,
          ]}
          onPress={() => navigation.navigate('HomeScreen')}
        >
          <Text style={styles.navEmoji}>🏠</Text>
          <Text style={styles.navLabel}>Główna</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.navButton,
            currentRoute === 'QuizSelectScreen' && styles.activeNavButton,
          ]}
          onPress={() => navigation.navigate('QuizSelectScreen')}
        >
          <Text style={styles.navEmoji}>🎯</Text>
          <Text style={styles.navLabel}>Quizy</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.navButton,
            currentRoute === 'YourProfile' && styles.activeNavButton,
          ]}
          onPress={() => navigation.navigate('YourProfile')}
        >
          <Text style={styles.navEmoji}>👤</Text>
          <Text style={styles.navLabel}>Profil</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.navButton,
            currentRoute === 'TitleSelectScreen' && styles.activeNavButton,
          ]}
          onPress={() => navigation.navigate('TitleSelectScreen')}
        >
          <Text style={styles.navEmoji}>🏅</Text>
          <Text style={styles.navLabel}>Tytuły</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.navButton,
            currentRoute === 'Settings' && styles.activeNavButton,
          ]}
          onPress={() => navigation.navigate('Settings')}
        >
          <Text style={styles.navEmoji}>⚙️</Text>
          <Text style={styles.navLabel}>Ustawienia</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1F1F1F',
  },
  cardScroll: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingBottom: 80,
  },
  cardContainer: {
    flex: 1,
    paddingVertical: 20,
    alignItems: 'center',
    justifyContent: 'space-evenly',
  },
  card: {
    width: width * 0.9,
    backgroundColor: '#2A2A2A',
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
    elevation: 6,
    marginVertical: 10,
  },
  createCard: {
    borderLeftWidth: 5,
    borderLeftColor: '#4CAF50',
  },
  searchCard: {
    borderLeftWidth: 5,
    borderLeftColor: '#2196F3',
  },
  manageCard: {
    borderLeftWidth: 5,
    borderLeftColor: '#FF9800',
  },
  historyCard: {
    borderLeftWidth: 5,
    borderLeftColor: '#9C27B0',
  },
  icon: {
    width: 50,
    height: 50,
    marginBottom: 15,
    tintColor: '#FFF',
  },
  title: {
    fontSize: 22,
    fontWeight: '600',
    color: '#FFF',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 14,
    color: '#BBB',
  },

  bottomNavigation: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    backgroundColor: '#2d2d2d',
    paddingVertical: 12,
    borderTopWidth: 1,
    borderTopColor: '#444',
  },
  navButton: { flex: 1, alignItems: 'center', paddingVertical: 4 },
  activeNavButton: {
    backgroundColor: '#374151',
    borderRadius: 8,
    marginHorizontal: 4,
  },
  navEmoji: { fontSize: 20 },
  navLabel: { color: '#CCC', fontSize: 10, marginTop: 2 },
});

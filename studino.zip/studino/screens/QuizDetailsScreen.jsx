import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  ScrollView,
} from 'react-native';
import {
  getFirestore,
  doc,
  getDoc,
  collection,
} from '@react-native-firebase/firestore';
import { useNavigation } from '@react-navigation/native';

const subjectImages = {
  'Język polski': require('../images/subject_images/JezykPolski.png'),
  Matematyka: require('../images/subject_images/Matematyka.png'),
  'Język angielski': require('../images/subject_images/JezykAngielski.png'),
  'Język niemiecki': require('../images/subject_images/JezykNiemiecki.png'),
  'Język francuski': require('../images/subject_images/JezykFrancuski.png'),
  'Język hiszpański': require('../images/subject_images/JezykHiszpanski.png'),
  'Język rosyjski': require('../images/subject_images/JezykRosyjski.png'),
  'Język włoski': require('../images/subject_images/JezykWloski.png'),
  'Inny język': require('../images/subject_images/InneJezyki.png'),
  Informatyka: require('../images/subject_images/Informatyka.png'),
  Plastyka: require('../images/subject_images/Plastyka.png'),
  Muzyka: require('../images/subject_images/Muzyka.png'),
  WF: require('../images/subject_images/WF.png'),
  Religia: require('../images/subject_images/Religia.png'),
  Etyka: require('../images/subject_images/Etyka.png'),
  Historia: require('../images/subject_images/Historia.png'),
  Przyroda: require('../images/subject_images/Przyroda.png'),
  Biologia: require('../images/subject_images/Biologia.png'),
  Chemia: require('../images/subject_images/Chemia.png'),
  Fizyka: require('../images/subject_images/Fizyka.png'),
  Geografia: require('../images/subject_images/Geografia.png'),
  Technika: require('../images/subject_images/Technika.png'),
  'Wiedza o społeczeństwie': require('../images/subject_images/WOS.png'),
  'Edukacja dla bezpieczeństwa': require('../images/subject_images/EDB.png'),
  'Bezpieczeństwo i higiena pracy': require('../images/subject_images/BHP.png'),
  'Podstawy przedsiębiorczości': require('../images/subject_images/PodstawyPrzedsiebiorczosci.png'),
  'Historia sztuki': require('../images/subject_images/HistoriaSztuki.png'),
  Filozofia: require('../images/subject_images/Filozofia.png'),
  Inne: require('../images/subject_images/Inne.png'),
};

const getDifficultyStyle = diff => {
  switch (diff) {
    case 'Łatwy':
      return { color: '#4CAF50' };
    case 'Średni':
      return { color: '#FF9800' };
    case 'Trudny':
      return { color: '#F44336' };
    default:
      return { color: '#fff' };
  }
};

const getLevelStyle = lvl =>
  lvl === 'Podstawowy' ? { color: '#2196F3' } : { color: '#9C27B0' };

const getPercentStyle = pct => {
  if (pct >= 80) return { color: '#70ff75' };
  if (pct >= 50) return { color: '#FF9800' };
  return { color: '#c21b0f' };
};

export default function QuizDetailsScreen({ quiz, onBack, onStartQuiz }) {
  const [loading, setLoading] = useState(true);
  const [quizData, setQuizData] = useState(null);
  const [author, setAuthor] = useState(null);
  const navigation = useNavigation();

  useEffect(() => {
    fetchQuizDetails();
  }, []);

  const fetchQuizDetails = async () => {
    try {
      const db = getFirestore();

      const quizDocRef = doc(db, 'quizzes', quiz.id);
      const quizSnap = await getDoc(quizDocRef);

      if (!quizSnap.exists()) {
        Alert.alert('Błąd', 'Quiz nie istnieje.');
      } else {
        const data = { id: quizSnap.id, ...quizSnap.data() };
        setQuizData(data);

        let authorObj = null;
        if (data.created_by) {
          const userDocRef = doc(db, 'users', data.created_by);
          const userSnap = await getDoc(userDocRef);
          if (userSnap.exists()) {
            authorObj = {
              uid: data.created_by,
              username: userSnap.data().username,
              exists: true,
            };
          } else if (data.created_by_name) {
            authorObj = {
              uid: null,
              username: data.created_by_name,
              exists: false,
            };
          }
        }
        setAuthor(authorObj);
      }
    } catch (err) {
      Alert.alert('Błąd', 'Nie udało się pobrać szczegółów.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#6495ED" />
        <Text style={styles.loadingText}>Ładowanie...</Text>
      </View>
    );
  }

  if (!quizData) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>Brak quizu</Text>
        <TouchableOpacity style={styles.backButton} onPress={onBack}>
          <Text style={styles.backButtonText}>Powrót</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const plays = quizData.playsCount || 0;
  const avgPercent = plays
    ? Math.round((quizData.totalPercentage / plays) * 10) / 10
    : 0;
  const diffStyle = getDifficultyStyle(quizData.difficulty);
  const lvlStyle = getLevelStyle(quizData.level);
  const pctStyle = getPercentStyle(avgPercent);

  return (
    <ScrollView style={styles.container}>
      <TouchableOpacity style={styles.backButton} onPress={onBack}>
        <Text style={styles.backButtonText}>← Powrót</Text>
      </TouchableOpacity>

      <View style={styles.quizHeader}>
        {subjectImages[quizData.subject] && (
          <Image
            source={subjectImages[quizData.subject]}
            style={styles.subjectImage}
          />
        )}
        <View style={styles.quizInfo}>
          <Text style={styles.quizTitle}>{quizData.title}</Text>
          <Text style={styles.quizSubject}>{quizData.subject}</Text>
          {author ? (
            author.exists ? (
              <TouchableOpacity
                onPress={() =>
                  navigation.navigate('PublicProfileScreen', {
                    uid: author.uid,
                  })
                }
              >
                <Text style={styles.authorText}>@{author.username}</Text>
              </TouchableOpacity>
            ) : (
              <Text style={styles.authorText}>
                @{author.username} - konto usunięte
              </Text>
            )
          ) : (
            <Text style={styles.unknownAuthor}>Nieznany autor</Text>
          )}
        </View>
      </View>

      <View style={styles.statsContainer}>
        <View style={styles.statItem}>
          <Text style={styles.statNumber}>
            {quizData.questions?.length || 0}
          </Text>
          <Text style={styles.statLabel}>Pytań</Text>
        </View>

        <View style={styles.statItem}>
          <Text style={[styles.statNumber, pctStyle]}>{avgPercent}%</Text>
          <Text style={styles.statLabel}>Średnio %</Text>
        </View>

        <View style={styles.statItem}>
          <Text style={[styles.statNumber, diffStyle]}>
            {quizData.difficulty}
          </Text>
          <Text style={styles.statLabel}>Trudność</Text>
        </View>

        <View style={styles.statItem}>
          <Text style={styles.statNumber}>{plays}</Text>
          <Text style={styles.statLabel}>Rozegrane</Text>
        </View>

        <View style={styles.statItem}>
          <Text style={styles.statNumber}>{quizData.likes || 0}</Text>
          <Text style={styles.statLabel}>Polubień</Text>
        </View>

        <View style={styles.statItem}>
          <Text style={[styles.statNumber, lvlStyle]}>{quizData.level}</Text>
          <Text style={styles.statLabel}>Poziom zaawansowania</Text>
        </View>
      </View>

      {quizData.description ? (
        <View style={styles.descriptionContainer}>
          <Text style={styles.descriptionTitle}>Opis:</Text>
          <Text style={styles.descriptionText}>{quizData.description}</Text>
        </View>
      ) : null}

      <TouchableOpacity
        style={styles.playButton}
        onPress={() => onStartQuiz(quizData)}
      >
        <Text style={styles.playButtonText}>🎮 Rozpocznij Quiz</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#202020', padding: 16 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#202020',
  },
  loadingText: { marginTop: 10, color: '#ccc', fontSize: 16 },
  errorText: {
    color: '#ff6b6b',
    fontSize: 18,
    textAlign: 'center',
    marginTop: 100,
  },

  backButton: { alignSelf: 'flex-start', padding: 10, marginBottom: 20 },
  backButtonText: { color: '#6495ED', fontSize: 16, fontWeight: 'bold' },

  quizHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 30 },
  subjectImage: { width: 80, height: 80, borderRadius: 12, marginRight: 16 },
  quizInfo: { flex: 1 },

  quizTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 8,
  },
  quizSubject: {
    fontSize: 16,
    color: '#fcff61',
    fontWeight: 'bold',
    marginBottom: 4,
  },
  authorText: { color: '#6495ED', fontWeight: 'bold', marginTop: 4 },
  unknownAuthor: { color: '#AAA', marginTop: 4 },

  statsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    backgroundColor: '#2B2B2B',
    borderRadius: 12,
    padding: 12,
    marginBottom: 20,
  },
  statItem: { alignItems: 'center', width: '45%', marginVertical: 8 },
  statNumber: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#CCC',
    marginBottom: 4,
  },
  statLabel: { fontSize: 12, color: '#aaa', textAlign: 'center' },

  descriptionContainer: {
    backgroundColor: '#2B2B2B',
    borderRadius: 12,
    padding: 16,
    marginBottom: 30,
  },
  descriptionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 8,
  },
  descriptionText: { fontSize: 16, color: '#ccc', lineHeight: 24 },

  playButton: {
    backgroundColor: '#6495ED',
    borderRadius: 25,
    paddingVertical: 16,
    paddingHorizontal: 32,
    alignItems: 'center',
    marginBottom: 30,
  },
  playButtonText: { color: '#fff', fontSize: 20, fontWeight: 'bold' },
});

import React, { useState, useCallback, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  SafeAreaView,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  View,
} from 'react-native';
import {
  getFirestore,
  doc,
  updateDoc,
  increment,
} from '@react-native-firebase/firestore';
import { getAuth } from '@react-native-firebase/auth';
import { useNavigation } from '@react-navigation/native';

import ELEMENTS_DATA from '../jsons/ChemistryElements.json';

const MODE_LABELS = {
  name2symbol: 'Nazwa → Symbol',
  name2atomicNumber: 'Nazwa → Liczba atomowa',
  name2atomicMass: 'Nazwa → Masa atomowa',
  atomicNumber2name: 'Liczba atomowa → Nazwa',
  symbol2name: 'Symbol → Nazwa',
  atomicMass2name: 'Masa atomowa → Nazwa',
};

export default function ChemistryQuizScreen({ route }) {
  const navigation = useNavigation();
  const { mode } = route.params;
  const [elements, setElements] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [question, setQuestion] = useState(null);
  const [answer, setAnswer] = useState('');
  const [feedback, setFeedback] = useState(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [showUnansweredWarning, setShowUnansweredWarning] = useState(false);

  useEffect(() => {
    setElements(ELEMENTS_DATA);
    setQuestion(getRandomElement(ELEMENTS_DATA));
    setIsLoading(false);
  }, []);

  function getRandomElement(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  const nextQuestion = useCallback(() => {
    if (!elements.length) return;
    let next = getRandomElement(elements);
    let tries = 0;
    while (question && next.name === question.name && tries < 10) {
      next = getRandomElement(elements);
      tries++;
    }
    setQuestion(next);
    setAnswer('');
    setFeedback(null);
    setIsAnswered(false);
    setShowUnansweredWarning(false);
  }, [question, elements]);

  const handleCheck = async () => {
    if (!answer.trim()) {
      setFeedback('empty');
      return;
    }
    if (!question) return;

    let correctList = [];
    switch (mode) {
      case 'name2symbol':
        correctList = [question.symbol.toLowerCase()];
        break;
      case 'name2atomicNumber':
        correctList = [String(question.atomicNumber)];
        break;
      case 'name2atomicMass': {
        const m = question.atomicMass;
        correctList = [String(Math.floor(m)), String(Math.ceil(m))];
        break;
      }
      case 'atomicNumber2name':
      case 'symbol2name':
      case 'atomicMass2name':
        correctList = [question.name.toLowerCase()];
        break;
    }

    const userAns = answer.toLowerCase().trim();
    const isCorrect = correctList.includes(userAns);

    setFeedback(isCorrect ? 'correct' : 'wrong');
    setIsAnswered(true);
    setShowUnansweredWarning(false);

    try {
      const auth = getAuth();
      const uid = auth.currentUser.uid;
      const db = getFirestore();
      const userDocRef = doc(db, 'users', uid);
      await updateDoc(userDocRef, {
        chemistryAnswered: increment(1),
        chemistryCorrect: increment(isCorrect ? 1 : 0),
      });
    } catch (e) {
      console.warn('Błąd aktualizacji statystyk chemii:', e);
    }
  };

  const handleNextPress = () => {
    if (!isAnswered) {
      setShowUnansweredWarning(true);
      return;
    }
    nextQuestion();
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text style={styles.loadingText}>Ładowanie danych…</Text>
      </SafeAreaView>
    );
  }
  if (!question) {
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.errorText}>Brak danych do wyświetlenia</Text>
      </SafeAreaView>
    );
  }

  let promptText = '';
  let promptSubtext = '';
  if (mode === 'atomicMass2name') {
    const approx = question.atomicMass.toFixed(2);
    promptText = `~${approx}`;
    promptSubtext = '(w przybliżeniu)';
  } else {
    switch (mode) {
      case 'name2symbol':
      case 'name2atomicNumber':
      case 'name2atomicMass':
        promptText = question.name;
        break;
      case 'atomicNumber2name':
        promptText = String(question.atomicNumber);
        break;
      case 'symbol2name':
        promptText = question.symbol;
        break;
    }
  }

  let feedbackText = '';
  if (feedback === 'correct') {
    feedbackText = '✔️ Poprawnie!';
  } else if (feedback === 'wrong') {
    let correct;
    switch (mode) {
      case 'name2symbol':
        correct = question.symbol;
        break;
      case 'name2atomicNumber':
        correct = question.atomicNumber;
        break;
      case 'name2atomicMass':
        correct = Math.round(question.atomicMass);
        break;
      default:
        correct = question.name;
    }
    feedbackText = `❌ Poprawnie: ${correct}`;
  } else if (feedback === 'empty') {
    feedbackText = '❗ Proszę wpisać odpowiedź.';
  }
  const warningText = showUnansweredWarning
    ? '❗ Najpierw odpowiedz na pytanie.'
    : '';

  let keyboardType = 'default';
  if (mode === 'name2atomicNumber' || mode === 'name2atomicMass') {
    keyboardType = 'numeric';
  }

  return (
    <SafeAreaView
      style={[
        styles.container,
        { paddingTop: Platform.OS === 'android' ? 60 : 20 },
      ]}
    >
      <TouchableOpacity
        style={styles.backButton}
        onPress={() => navigation.goBack()}
      >
        <Text style={styles.backArrow}>← Powrót</Text>
      </TouchableOpacity>

      <Text style={styles.modeLabel}>{MODE_LABELS[mode]}</Text>
      <Text style={styles.prompt}>{promptText}</Text>
      {!!promptSubtext && <Text style={styles.subtext}>{promptSubtext}</Text>}

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={styles.inputWrapper}
      >
        <TextInput
          style={styles.input}
          value={answer}
          onChangeText={text => {
            setAnswer(text);
            if (feedback) setFeedback(null);
            if (showUnansweredWarning) setShowUnansweredWarning(false);
          }}
          placeholder="Wpisz odpowiedź"
          placeholderTextColor="#AAA"
          keyboardType={keyboardType}
          returnKeyType="done"
          onSubmitEditing={handleCheck}
        />

        <TouchableOpacity
          style={[styles.checkBtn, isAnswered && styles.checkBtnDisabled]}
          onPress={handleCheck}
          disabled={isAnswered}
        >
          <Text
            style={[styles.checkTxt, isAnswered && styles.checkTxtDisabled]}
          >
            {isAnswered ? 'Sprawdzone' : 'Sprawdź'}
          </Text>
        </TouchableOpacity>
      </KeyboardAvoidingView>

      {(feedback !== null || showUnansweredWarning) && (
        <Text
          style={[
            styles.feedback,
            feedback === 'correct' && styles.feedbackCorrect,
            feedback === 'wrong' && styles.feedbackWrong,
            (feedback === 'empty' || showUnansweredWarning) &&
              styles.feedbackWarning,
          ]}
        >
          {feedbackText || warningText}
        </Text>
      )}

      <TouchableOpacity style={styles.nextBtn} onPress={handleNextPress}>
        <Text style={styles.nextTxt}>Następne</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#2C2C2E',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  backButton: {
    position: 'absolute',
    top: Platform.OS === 'android' ? 20 : 10,
    left: 20,
    zIndex: 1,
  },
  backArrow: {
    color: '#007AFF',
    fontSize: 16,
    fontWeight: '600',
  },
  modeLabel: {
    color: '#CCC',
    fontSize: 16,
    marginBottom: 8,
    fontStyle: 'italic',
  },
  loadingText: {
    color: '#FFF',
    fontSize: 18,
    marginTop: 10,
  },
  errorText: {
    color: '#FF3B30',
    fontSize: 18,
    textAlign: 'center',
  },
  prompt: {
    color: '#FFF',
    fontSize: 32,
    fontWeight: '700',
    marginBottom: 4,
    textAlign: 'center',
  },
  subtext: {
    color: '#AAA',
    fontSize: 14,
    marginBottom: 20,
  },
  inputWrapper: {
    width: '85%',
    alignItems: 'center',
    marginBottom: 20,
  },
  input: {
    width: '100%',
    borderWidth: 2,
    borderColor: '#48484A',
    borderRadius: 12,
    padding: 16,
    fontSize: 20,
    color: '#FFF',
    backgroundColor: '#1C1C1E',
    marginBottom: 16,
    textAlign: 'center',
    fontWeight: '500',
  },
  checkBtn: {
    backgroundColor: '#34C759',
    paddingVertical: 14,
    paddingHorizontal: 40,
    borderRadius: 12,
  },
  checkBtnDisabled: {
    backgroundColor: '#48484A',
  },
  checkTxt: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: '700',
  },
  checkTxtDisabled: {
    color: '#8E8E93',
  },
  feedback: {
    fontSize: 18,
    marginTop: 20,
    textAlign: 'center',
    fontWeight: '600',
  },
  feedbackCorrect: {
    color: '#34C759',
  },
  feedbackWrong: {
    color: '#FF3B30',
  },
  feedbackWarning: {
    color: '#FF9500',
  },
  nextBtn: {
    marginTop: 20,
    backgroundColor: '#007AFF',
    paddingVertical: 14,
    paddingHorizontal: 40,
    borderRadius: 12,
  },
  nextTxt: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: '700',
  },
});

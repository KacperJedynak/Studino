import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  BackHandler,
} from 'react-native';
import {
  getFirestore,
  doc,
  collection,
  writeBatch,
  getDoc,
  increment,
} from '@react-native-firebase/firestore';
import { getAuth } from '@react-native-firebase/auth';
import { useNavigation, CommonActions } from '@react-navigation/native';

export default function QuizResultsScreen({ results, user, route }) {
  const navigation = useNavigation();
  const fromHistory = route?.params?.fromHistory || false;

  const auth = getAuth();
  const currentUser = user || auth.currentUser;
  const userId = route?.params?.userId || currentUser?.uid;

  const {
    quiz,
    answers,
    correctAnswers,
    totalQuestions,
    percentage,
    totalTime,
    completedAt,
  } = results;

  React.useEffect(() => {
    if (!fromHistory) saveResult();
  }, [fromHistory]);

  React.useEffect(() => {
    const handler = BackHandler.addEventListener('hardwareBackPress', () => {
      fromHistory ? goToHistory() : goToBrowse();
      return true;
    });
    return () => handler.remove();
  }, [fromHistory]);

  const goToBrowse = () => {
    navigation.dispatch(
      CommonActions.reset({
        index: 1,
        routes: [{ name: 'HomeScreen' }, { name: 'BrowseQuizesScreen' }],
      })
    );
  };
  const goToHistory = () => navigation.goBack();

  const handlePlayAgain = () => {
    navigation.reset({
      index: 1,
      routes: [
        { name: 'HomeScreen' },
        { name: 'QuizGameScreen', params: { quiz } },
      ],
    });
  };

  const saveResult = async () => {
    if (!userId) return;
    const db = getFirestore();
    const batch = writeBatch(db);
    try {
      const quizRef = doc(db, 'quizzes', quiz.id);
      const resRef = doc(collection(db, 'quiz_results'));
      const userRef = doc(db, 'users', userId);

      batch.set(resRef, {
        userId,
        quizId: quiz.id,
        correctAnswers,
        totalQuestions,
        percentage,
        totalTime,
        completedAt,
        answers: answers.map(a => ({
          questionIndex: a.questionIndex,
          questionText: a.questionText,
          selected: a.selected,
          correct: a.correct,
          isCorrect: a.isCorrect,
          timeSpent: a.timeSpent,
          type: a.type || 'text',
          ...(Array.isArray(a.options) ? { options: a.options } : {}),
        })),
      });

      batch.update(quizRef, {
        playsCount: increment(1),
        totalPercentage: increment(percentage),
      });

      const uSnap = await getDoc(userRef);
      const u = uSnap.exists() ? uSnap.data() : {};
      const prevCurrent = u.currentStreak || 0;
      const prevLongest = u.longestStreak || 0;
      const good = percentage >= 90;
      const newCurr = good ? prevCurrent + 1 : 0;
      const newLong = Math.max(prevLongest, newCurr);

      batch.update(userRef, {
        quizzesPlayed: increment(1),
        totalPercentage: increment(percentage),
        totalQuizTime: increment(totalTime / 1000 / 60),
        totalQuestionsAnswered: increment(answers.length),
        currentStreak: newCurr,
        longestStreak: newLong,
      });

      await batch.commit();
    } catch (e) {
      console.error('Error saving result:', e);
    }
  };

  const formatTime = ms => {
    const secs = Math.floor(ms / 1000);
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return mins > 0 ? `${mins}m ${rem}s` : `${rem}s`;
  };

  const getPerfMsg = () => {
    if (percentage >= 90) return 'Wspaniały wynik! 🎉';
    if (percentage >= 70) return 'Dobra robota! 👏';
    if (percentage >= 50) return 'Niezły wynik! 👍';
    return 'Potrzeba więcej praktyki! 💪';
  };

  const getPerfColor = () => {
    if (percentage >= 90) return '#4CAF50';
    if (percentage >= 70) return '#FF9800';
    if (percentage >= 50) return '#FFC107';
    return '#f44336';
  };

  const renderAnswer = (answer, options) => {
    if (answer === '' || answer === undefined) return 'Brak odpowiedzi';
    if (Array.isArray(options) && options.length) {
      if (Array.isArray(answer)) {
        return answer
          .map(idx => `${String.fromCharCode(65 + idx)}. ${options[idx]}`)
          .join('\n');
      }
      if (typeof answer === 'number') {
        return `${String.fromCharCode(65 + answer)}. ${options[answer]}`;
      }
    }
    if (typeof answer === 'boolean') return answer ? 'Prawda' : 'Fałsz';
    return String(answer);
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={styles.backButton}
        onPress={fromHistory ? goToHistory : goToBrowse}
      >
        <Text style={styles.backArrow}>← Powrót</Text>
      </TouchableOpacity>

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <Text style={styles.title}>
            {fromHistory ? 'Historia Quizu' : 'Wyniki Quizu'}
          </Text>
          <Text style={styles.quizTitle}>{quiz.title}</Text>
          {fromHistory && (
            <Text style={styles.historyNote}>
              📅 {new Date(completedAt).toLocaleDateString('pl-PL')}
            </Text>
          )}
        </View>

        <View style={styles.scoreContainer}>
          <Text style={[styles.percentage, { color: getPerfColor() }]}>
            {Math.round(percentage)}%
          </Text>
          <Text style={[styles.perfMsg, { color: getPerfColor() }]}>
            {getPerfMsg()}
          </Text>
        </View>

        <View style={styles.statsContainer}>
          <View style={styles.statRow}>
            <Text style={styles.statLabel}>Poprawne:</Text>
            <Text style={styles.statValue}>
              {correctAnswers} / {totalQuestions}
            </Text>
          </View>
          <View style={styles.statRow}>
            <Text style={styles.statLabel}>Czas:</Text>
            <Text style={styles.statValue}>{formatTime(totalTime)}</Text>
          </View>
          <View style={styles.statRow}>
            <Text style={styles.statLabel}>Śr. czas/pyt:</Text>
            <Text style={styles.statValue}>
              {formatTime(totalTime / totalQuestions)}
            </Text>
          </View>
        </View>

        <View style={styles.detailsContainer}>
          <Text style={styles.detailsTitle}>Szczegóły:</Text>
          {answers.length > 0 ? (
            answers.map((ans, i) => (
              <View key={i} style={styles.answerDetail}>
                <View style={styles.answerHeader}>
                  <Text style={styles.questionNumber}>Pytanie {i + 1}</Text>
                  <View
                    style={[
                      styles.statusBadge,
                      {
                        backgroundColor: ans.isCorrect
                          ? '#4CAF50'
                          : '#f44336',
                      },
                    ]}
                  >
                    <Text style={styles.statusText}>
                      {ans.isCorrect ? '✓' : '✗'}
                    </Text>
                  </View>
                </View>
                <Text style={styles.questionText}>{ans.questionText}</Text>
                <Text style={styles.yourAnswer}>Twoja odpowiedź:</Text>
                <View
                  style={[
                    styles.answerBlock,
                    {
                      backgroundColor: ans.isCorrect
                        ? '#2d5a2d'
                        : '#5a2d2d',
                    },
                  ]}
                >
                  <Text style={styles.answerText}>
                    {renderAnswer(ans.selected, ans.options)}
                  </Text>
                </View>
                {!ans.isCorrect && (
                  <>
                    <Text style={styles.correctAnswer}>
                      Poprawna odpowiedź:
                    </Text>
                    <View
                      style={[
                        styles.answerBlock,
                        { backgroundColor: '#2d5a2d' },
                      ]}
                    >
                      <Text style={styles.answerText}>
                        {renderAnswer(ans.correct, ans.options)}
                      </Text>
                    </View>
                  </>
                )}
                <Text style={styles.timeSpent}>
                  ⏱️ Czas: {formatTime(ans.timeSpent || 0)}
                </Text>
              </View>
            ))
          ) : (
            <View style={styles.noAnswersContainer}>
              <Text style={styles.noAnswersText}>
                Brak szczegółowych odpowiedzi
              </Text>
            </View>
          )}
        </View>

        <View style={styles.buttonsContainer}>
          {!fromHistory && (
            <TouchableOpacity
              style={styles.playAgainBtn}
              onPress={handlePlayAgain}
            >
              <Text style={styles.playAgainText}>Zagraj ponownie</Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity
            style={styles.backBtn}
            onPress={fromHistory ? goToHistory : goToBrowse}
          >
            <Text style={styles.backBtnText}>
              {fromHistory ? 'Powrót do historii' : 'Powrót do quizów'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#202020' },

  backButton: {
    position: 'absolute',
    top: 16,
    left: 12,
    zIndex: 1,
  },
  backArrow: { color: '#6495ED', fontSize: 16, fontWeight: '600' },

  content: { paddingTop: 50, paddingBottom: 40 },

  header: {
    paddingHorizontal: 20,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#333',
    paddingBottom: 12,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 6,
  },
  quizTitle: {
    fontSize: 18,
    color: '#6495ED',
    textAlign: 'center',
  },
  historyNote: {
    fontSize: 14,
    color: '#aaa',
    marginTop: 6,
  },

  scoreContainer: { alignItems: 'center', paddingVertical: 20 },
  percentage: { fontSize: 48, fontWeight: 'bold', marginBottom: 8 },
  perfMsg: { fontSize: 18, fontWeight: '600' },

  statsContainer: {
    backgroundColor: '#2a2a2a',
    margin: 20,
    padding: 16,
    borderRadius: 12,
  },
  statRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  statLabel: { fontSize: 16, color: '#ccc' },
  statValue: { fontSize: 16, color: '#fff', fontWeight: '600' },

  detailsContainer: { marginHorizontal: 20, marginBottom: 20 },
  detailsTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 12,
  },
  answerDetail: {
    backgroundColor: '#2a2a2a',
    marginBottom: 12,
    padding: 12,
    borderRadius: 12,
  },
  answerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  questionNumber: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#6495ED',
  },
  statusBadge: {
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  statusText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },

  questionText: {
    fontSize: 16,
    color: '#fff',
    marginBottom: 12,
    lineHeight: 22,
  },
  yourAnswer: { fontSize: 14, color: '#ccc', marginBottom: 6 },
  correctAnswer: { fontSize: 14, color: '#ccc', marginBottom: 6 },
  answerBlock: { padding: 10, borderRadius: 8, marginBottom: 6 },
  answerText: { fontSize: 15, color: '#fff', lineHeight: 20 },
  timeSpent: { fontSize: 12, color: '#999', marginTop: 6 },

  noAnswersContainer: { alignItems: 'center', padding: 20 },
  noAnswersText: { fontSize: 16, color: '#999' },

  buttonsContainer: { paddingHorizontal: 20 },
  playAgainBtn: {
    backgroundColor: '#6495ED',
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 12,
  },
  playAgainText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  backBtn: {
    backgroundColor: '#333',
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  backBtnText: { color: '#fff', fontSize: 16 },
});

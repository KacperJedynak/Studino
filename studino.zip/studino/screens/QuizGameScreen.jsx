import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Dimensions,
  TextInput,
  Alert,
  BackHandler,
} from 'react-native';

const { width } = Dimensions.get('window');

function shuffleArray(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export default function QuizGameScreen({ quiz, onQuizComplete, onBack }) {
  const [shuffledQuestions, setShuffledQuestions] = useState([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState([]);
  const [textAnswer, setTextAnswer] = useState('');
  const [answersHistory, setAnswersHistory] = useState([]);
  const [questionTimes, setQuestionTimes] = useState([]);
  const [startTime, setStartTime] = useState(null);
  const [questionStartTime, setQuestionStartTime] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    const qs = Array.isArray(quiz.questions) ? quiz.questions : [];
    const shuffledQs = shuffleArray(qs).map(q => {
      if (q.type === 'mcq') {
        const paired = q.options.map((opt, i) => ({ opt, i }));
        const sh = shuffleArray(paired);
        const newOptions = sh.map(p => p.opt);
        const newCorrect = sh
          .map((p, newIdx) => (q.correctIndexes.includes(p.i) ? newIdx : null))
          .filter(i => i !== null);
        return {
          ...q,
          options: newOptions,
          correctIndexes: newCorrect,
        };
      }
      return { ...q };
    });

    setShuffledQuestions(shuffledQs);
    setAnswersHistory(Array(shuffledQs.length).fill(null));
    setQuestionTimes(Array(shuffledQs.length).fill(0));

    const now = Date.now();
    setStartTime(now);
    setQuestionStartTime(now);
  }, [quiz]);

  const navigateTo = nextIndex => {
    const now = Date.now();
    const chunk = now - questionStartTime;
    setQuestionTimes(prev => {
      const copy = [...prev];
      copy[currentQuestion] += chunk;
      return copy;
    });
    setQuestionStartTime(now);
    setCurrentQuestion(nextIndex);
    setSelectedAnswers([]);
    setTextAnswer('');
    setErrorMsg('');
  };

  const confirmExit = () => {
    Alert.alert(
      'Potwierdź',
      'Czy na pewno chcesz wyjść? Twoje postępy nie zostaną zapisane.',
      [
        { text: 'Anuluj', style: 'cancel' },
        { text: 'Tak', onPress: () => onBack() },
      ],
    );
  };

  useEffect(() => {
    const handler = BackHandler.addEventListener('hardwareBackPress', () => {
      confirmExit();
      return true;
    });
    return () => handler.remove();
  }, []);

  const totalQuestions = shuffledQuestions.length;
  const currentQ = shuffledQuestions[currentQuestion] || {};
  const answersList = Array.isArray(currentQ.options) ? currentQ.options : [];
  const correctIndexes = Array.isArray(currentQ.correctIndexes)
    ? currentQ.correctIndexes
    : [];
  const isMulti = currentQ.type === 'mcq' && correctIndexes.length > 1;

  const toggleAnswer = idx => {
    if (currentQ.type === 'text') return;
    if (isMulti) {
      setSelectedAnswers(prev =>
        prev.includes(idx) ? prev.filter(i => i !== idx) : [...prev, idx],
      );
    } else {
      setSelectedAnswers([idx]);
    }
  };

  const arraysEqual = (a, b) => {
    if (a.length !== b.length) return false;
    const sa = [...a].sort(),
      sb = [...b].sort();
    return sa.every((v, i) => v === sb[i]);
  };

  const handleNext = () => {
    if (
      (currentQ.type === 'mcq' || currentQ.type === 'boolean') &&
      selectedAnswers.length === 0
    ) {
      setErrorMsg('Brak odpowiedzi');
      return;
    }
    if (currentQ.type === 'text' && !textAnswer.trim()) {
      setErrorMsg('Brak odpowiedzi');
      return;
    }
    setErrorMsg('');

    const now = Date.now();
    const chunk = now - questionStartTime;
    const updatedTimes = [...questionTimes];
    updatedTimes[currentQuestion] += chunk;

    const isCorrect =
      currentQ.type === 'mcq'
        ? arraysEqual(selectedAnswers, correctIndexes)
        : currentQ.type === 'boolean'
        ? Boolean(currentQ.answer) === selectedAnswers[0]
        : textAnswer.trim().toLowerCase() ===
          String(currentQ.answer).trim().toLowerCase();

    const record = {
      questionIndex: currentQuestion,
      questionText: currentQ.question,
      options: currentQ.options,
      type: currentQ.type,
      selected:
        currentQ.type === 'text'
          ? textAnswer
          : currentQ.type === 'mcq'
          ? selectedAnswers
          : selectedAnswers[0],
      correct:
        currentQ.type === 'text'
          ? currentQ.answer
          : currentQ.type === 'boolean'
          ? currentQ.answer
          : correctIndexes,
      isCorrect,
      timeSpent: updatedTimes[currentQuestion],
    };

    const newHistory = [...answersHistory];
    newHistory[currentQuestion] = record;
    setAnswersHistory(newHistory);
    setQuestionTimes(updatedTimes);

    if (currentQuestion + 1 < totalQuestions) {
      setQuestionStartTime(now);
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswers([]);
      setTextAnswer('');
    } else {
      const totalTime = now - startTime;
      const correctCount = newHistory.filter(h => h?.isCorrect).length;
      const percentage = Math.round((correctCount / totalQuestions) * 100);
      onQuizComplete({
        quiz,
        answers: newHistory,
        correctAnswers: correctCount,
        totalQuestions,
        percentage,
        totalTime,
        completedAt: new Date().toISOString(),
      });
    }
  };

  if (totalQuestions === 0) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>Brak pytań w quizie.</Text>
        <TouchableOpacity onPress={onBack} style={styles.backBtn}>
          <Text style={styles.backBtnText}>Powrót</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const progress = ((currentQuestion + 1) / totalQuestions) * 100;

  return (
    <ScrollView style={styles.container}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={confirmExit} style={styles.headerBtn}>
          <Text style={styles.headerText}>← Zakończ</Text>
        </TouchableOpacity>
        <Text style={styles.counter}>
          {currentQuestion + 1}/{totalQuestions}
        </Text>
      </View>

      <View style={styles.progressWrap}>
        <View style={styles.progressBar}>
          <View style={[styles.progressFill, { width: `${progress}%` }]} />
        </View>
        <Text style={styles.progressText}>{Math.round(progress)}%</Text>
      </View>

      <View style={styles.questionBox}>
        <Text style={styles.questionText}>{currentQ.question}</Text>
      </View>

      {isMulti && (
        <Text style={styles.multiInfo}>
          Wybierz wszystkie poprawne odpowiedzi
        </Text>
      )}

      <View style={styles.answersWrap}>
        {currentQ.type === 'mcq' &&
          answersList.map((ans, i) => (
            <TouchableOpacity
              key={i}
              style={[
                styles.answerBtn,
                selectedAnswers.includes(i) && styles.selectedAnswer,
              ]}
              onPress={() => toggleAnswer(i)}
            >
              <Text
                style={[
                  styles.answerText,
                  selectedAnswers.includes(i) && styles.selectedAnswerText,
                ]}
              >
                {String.fromCharCode(65 + i)}. {ans}
              </Text>
            </TouchableOpacity>
          ))}

        {currentQ.type === 'boolean' &&
          [true, false].map(val => (
            <TouchableOpacity
              key={String(val)}
              style={[
                styles.answerBtn,
                selectedAnswers.includes(val) && styles.selectedAnswer,
              ]}
              onPress={() => toggleAnswer(val)}
            >
              <Text
                style={[
                  styles.answerText,
                  selectedAnswers.includes(val) && styles.selectedAnswerText,
                ]}
              >
                {val ? 'Prawda' : 'Fałsz'}
              </Text>
            </TouchableOpacity>
          ))}

        {currentQ.type === 'text' && (
          <TextInput
            style={styles.textInput}
            placeholder="Wpisz odpowiedź..."
            placeholderTextColor="#AAA"
            value={textAnswer}
            onChangeText={setTextAnswer}
          />
        )}
      </View>

      {errorMsg ? <Text style={styles.validationText}>{errorMsg}</Text> : null}

      <TouchableOpacity style={styles.nextBtn} onPress={handleNext}>
        <Text style={styles.nextText}>
          {currentQuestion + 1 === totalQuestions
            ? 'Zakończ Quiz'
            : 'Następne pytanie'}
        </Text>
      </TouchableOpacity>

      {currentQuestion > 0 && (
        <TouchableOpacity
          onPress={() => navigateTo(currentQuestion - 1)}
          style={styles.previousBtn}
        >
          <Text style={styles.previousText}>Poprzednie pytanie</Text>
        </TouchableOpacity>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#202020', padding: 16 },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  headerBtn: { padding: 8 },
  headerText: { color: '#6495ED', fontSize: 16, fontWeight: 'bold' },
  counter: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  progressWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 30,
  },
  progressBar: {
    flex: 1,
    height: 8,
    backgroundColor: '#2B2B2B',
    borderRadius: 4,
    marginRight: 12,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#6495ED',
    borderRadius: 4,
  },
  progressText: { color: '#6495ED', fontSize: 14, fontWeight: 'bold' },
  questionBox: {
    backgroundColor: '#2B2B2B',
    borderRadius: 12,
    padding: 20,
    marginBottom: 10,
  },
  questionText: { color: '#fff', fontSize: 18, textAlign: 'center' },
  multiInfo: {
    color: '#FFEB3B',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 12,
  },
  answersWrap: { marginBottom: 10 },
  answerBtn: {
    backgroundColor: '#2B2B2B',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  selectedAnswer: {
    borderColor: '#6495ED',
    backgroundColor: '#1a3a5c',
  },
  answerText: { color: '#fff', fontSize: 16 },
  selectedAnswerText: { color: '#6495ED', fontWeight: 'bold' },
  textInput: {
    backgroundColor: '#2B2B2B',
    color: '#fff',
    padding: 16,
    borderRadius: 12,
    fontSize: 16,
    marginBottom: 20,
  },
  validationText: {
    color: '#ff6b6b',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 12,
  },
  nextBtn: {
    backgroundColor: '#6495ED',
    borderRadius: 25,
    paddingVertical: 16,
    alignItems: 'center',
  },
  nextText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  previousBtn: {
    backgroundColor: '#444',
    borderRadius: 25,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 12,
    marginBottom: 40,
  },
  previousText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  errorText: {
    color: '#ff6b6b',
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 20,
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  backBtn: {
    backgroundColor: '#6495ED',
    padding: 12,
    borderRadius: 25,
  },
  backBtnText: { color: '#fff', fontWeight: 'bold' },
});

import React, { useState, useCallback, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  SafeAreaView,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  View,
} from 'react-native';
import {
  getFirestore,
  doc,
  updateDoc,
  increment,
} from '@react-native-firebase/firestore';
import { getAuth } from '@react-native-firebase/auth';
import { useNavigation } from '@react-navigation/native';

export default function MathMinigameScreen({ route }) {
  const navigation = useNavigation();
  const { mode } = route.params;

  const [question, setQuestion] = useState(null);
  const [answer, setAnswer] = useState('');
  const [feedback, setFeedback] = useState(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [showWarning, setShowWarning] = useState(false);

  const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
  const fact = n => (n <= 1 ? 1 : n * fact(n - 1));

  const normalize = a => ((a % 360) + 360) % 360;
  const getQuadrant = a => (a < 90 ? 1 : a < 180 ? 2 : a < 270 ? 3 : 4);

  const BASE_SIN = { 0: '0', 30: '1/2', 45: '√2/2', 60: '√3/2', 90: '1' };
  const BASE_TAN = { 0: '0', 30: '√3/3', 45: '1', 60: '√3', 90: null };
  const BASE_COT = { 0: null, 30: '√3', 45: '1', 60: '√3/3', 90: '0' };

  function getTrig(func, angle) {
    const a = normalize(angle);
    const q = getQuadrant(a);

    let ref;
    if (q === 1) ref = a;
    else if (q === 2) ref = 180 - a;
    else if (q === 3) ref = a - 180;
    else ref = 360 - a;

    let val;
    switch (func) {
      case 'sin':
        val = BASE_SIN[ref] ?? null;
        break;
      case 'cos':
        val = BASE_SIN[normalize(90 - ref)] ?? null;
        break;
      case 'tan':
        val = BASE_TAN[ref] ?? null;
        break;
      case 'cot':
        val = BASE_COT[ref] ?? null;
        break;
      default:
        return null;
    }
    if (val == null) return null;

    const base = val.replace(/^-/, '');

    if (base === '0') {
      return '0';
    }

    const signMap = {
      sin: { 1: '', 2: '', 3: '-', 4: '-' },
      cos: { 1: '', 2: '-', 3: '-', 4: '' },
      tan: { 1: '', 2: '-', 3: '', 4: '-' },
      cot: { 1: '', 2: '-', 3: '', 4: '-' },
    };

    return signMap[func][q] + base;
  }

  const TRIG_OPTIONS = [
    '0',
    '1/2',
    '√2/2',
    '√3/2',
    '1',
    '-1/2',
    '-√2/2',
    '-√3/2',
    '-1',
    '√3',
    '√3/3',
    '-√3',
    '-√3/3',
    'brak',
  ];
  const generateTrig = () => {
    const internal = ['sin', 'cos', 'tan', 'cot'];
    const display = { tan: 'tg', cot: 'ctg' };
    let func, disp, angle, correct;
    do {
      func = internal[rand(0, internal.length - 1)];
      disp = display[func] || func;
      angle = [0, 30, 45, 60, 90][rand(0, 4)] + rand(-2, 2) * 360;
      correct = getTrig(func, angle);
    } while (correct === undefined);
    return {
      prompt: `${disp}(${angle}°)`,
      correct: correct === null ? 'brak' : correct,
      mcq: true,
      options: TRIG_OPTIONS,
    };
  };

  const generateSimple = () => {
    const ops = ['add', 'sub', 'mul', 'div', 'sqrt', 'cbrt', 'square', 'cube'];
    const op = ops[rand(0, ops.length - 1)];
    switch (op) {
      case 'add': {
        const a = rand(1, 999),
          b = rand(1, 1000 - a);
        return { prompt: `${a} + ${b}`, correct: `${a + b}`, mcq: false };
      }
      case 'sub': {
        const a = rand(-1000, 1000),
          b = rand(-1000, 1000);
        const prompt = b >= 0 ? `${a} - ${b}` : `${a} + ${Math.abs(b)}`;
        return { prompt, correct: `${a - b}`, mcq: false };
      }
      case 'mul': {
        let a, b;
        do {
          a = rand(1, 31);
          b = rand(1, Math.floor(1000 / a));
        } while (a * b > 1000);
        return { prompt: `${a} × ${b}`, correct: `${a * b}`, mcq: false };
      }
      case 'div': {
        const r = rand(1, 1000),
          d = rand(2, Math.floor(1000 / r));
        return { prompt: `${r * d} ÷ ${d}`, correct: `${r}`, mcq: false };
      }
      case 'sqrt': {
        let n, sq;
        do {
          n = rand(1, 31);
          sq = n * n;
        } while (sq > 1000);
        return { prompt: `√${sq}`, correct: `${n}`, mcq: false };
      }
      case 'cbrt': {
        let n, cu;
        do {
          n = rand(1, 10);
          cu = n ** 3;
        } while (cu > 1000);
        return { prompt: `³√${cu}`, correct: `${n}`, mcq: false };
      }
      case 'square': {
        const n = rand(1, 20);
        return { prompt: `${n}²`, correct: `${n * n}`, mcq: false };
      }
      case 'cube': {
        const n = rand(1, 10);
        return { prompt: `${n}³`, correct: `${n ** 3}`, mcq: false };
      }
    }
  };

  const generateAdvanced = () => {
    const ops = [
      'add',
      'sub',
      'mul',
      'div',
      'sqrt',
      'cbrt',
      'square',
      'cube',
      'factorial',
      'log',
      'trig',
    ];
    const op = ops[rand(0, ops.length - 1)];
    switch (op) {
      case 'add': {
        const a = rand(1, 2999),
          b = rand(1, 3000 - a);
        return { prompt: `${a} + ${b}`, correct: `${a + b}`, mcq: false };
      }
      case 'sub': {
        const a = rand(-3000, 3000),
          b = rand(-3000, 3000);
        const prompt = b >= 0 ? `${a} - ${b}` : `${a} + ${Math.abs(b)}`;
        return { prompt, correct: `${a - b}`, mcq: false };
      }
      case 'mul': {
        let a, b;
        do {
          a = rand(1, 54);
          b = rand(1, Math.floor(3000 / a));
        } while (a * b > 3000);
        return { prompt: `${a} × ${b}`, correct: `${a * b}`, mcq: false };
      }
      case 'div': {
        const r = rand(1, 3000),
          d = rand(2, Math.floor(3000 / r));
        return { prompt: `${r * d} ÷ ${d}`, correct: `${r}`, mcq: false };
      }
      case 'sqrt': {
        let n, sq;
        do {
          n = rand(1, 54);
          sq = n * n;
        } while (sq > 3000);
        return { prompt: `√${sq}`, correct: `${n}`, mcq: false };
      }
      case 'cbrt': {
        let n, cu;
        do {
          n = rand(1, 14);
          cu = n ** 3;
        } while (cu > 3000);
        return { prompt: `³√${cu}`, correct: `${n}`, mcq: false };
      }
      case 'square': {
        const n = rand(1, 30);
        return { prompt: `${n}²`, correct: `${n * n}`, mcq: false };
      }
      case 'cube': {
        const n = rand(1, 15);
        return { prompt: `${n}³`, correct: `${n ** 3}`, mcq: false };
      }
      case 'factorial': {
        const n = rand(0, 7);
        return { prompt: `${n}!`, correct: `${fact(n)}`, mcq: false };
      }
      case 'log': {
        const base = rand(2, 10);
        const maxExp = Math.floor(Math.log(3000) / Math.log(base));
        const exp = rand(0, maxExp),
          val = base ** exp;
        const sub = String(base).replace(/\d/g, d => '₀₁₂₃₄₅₆₇₈₉'[d]);
        return { prompt: `log${sub}(${val})`, correct: `${exp}`, mcq: false };
      }
      case 'trig':
        return generateTrig();
    }
  };

  const checkAnswer = useCallback(
    userAns => {
      if (!userAns.trim()) {
        setFeedback('empty');
        return false;
      }
      const isCorrect = userAns.trim() === question.correct;
      setFeedback(isCorrect ? 'correct' : 'wrong');
      setIsAnswered(true);

      const auth = getAuth();
      const uid = auth.currentUser?.uid;
      if (uid) {
        const db = getFirestore();
        const userDocRef = doc(db, 'users', uid);
        updateDoc(userDocRef, {
          mathAnswered: increment(1),
          mathCorrect: increment(isCorrect ? 1 : 0),
        }).catch(e => console.warn(e));
      }
      return true;
    },
    [question],
  );

  const nextQuestion = useCallback(() => {
    setAnswer('');
    setFeedback(null);
    setIsAnswered(false);
    setShowWarning(false);
    setQuestion(mode === 'simple' ? generateSimple() : generateAdvanced());
  }, [mode]);

  useEffect(() => {
    nextQuestion();
  }, [nextQuestion]);

  if (!question) return null;

  return (
    <SafeAreaView style={styles.container}>
      <TouchableOpacity
        style={styles.backButton}
        onPress={() => navigation.goBack()}
      >
        <Text style={styles.backArrow}>← Powrót</Text>
      </TouchableOpacity>

      <Text style={styles.modeLabel}>
        {mode === 'simple' ? 'Zwykłe działania' : 'Trudniejsze działania'}
      </Text>
      <Text style={styles.prompt}>{question.prompt}</Text>

      {question.mcq ? (
        <View style={styles.optionsWrapper}>
          {question.options.map(opt => (
            <TouchableOpacity
              key={opt}
              style={[
                styles.optionBtn,
                isAnswered && opt === question.correct && styles.optionCorrect,
                isAnswered &&
                  opt === answer &&
                  opt !== question.correct &&
                  styles.optionWrong,
              ]}
              disabled={isAnswered}
              onPress={() => {
                setAnswer(opt);
                checkAnswer(opt);
                setShowWarning(false);
              }}
            >
              <Text style={styles.optionTxt}>{opt}</Text>
            </TouchableOpacity>
          ))}
        </View>
      ) : (
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          style={styles.inputWrapper}
        >
          <TextInput
            style={[styles.input, isAnswered && styles.inputDisabled]}
            value={answer}
            onChangeText={t => {
              setAnswer(t);
              setFeedback(null);
              setShowWarning(false);
            }}
            placeholder="Wpisz odpowiedź"
            placeholderTextColor="#AAA"
            keyboardType="numeric"
            returnKeyType="done"
            editable={!isAnswered}
            onSubmitEditing={() => {
              if (checkAnswer(answer)) setShowWarning(false);
            }}
          />
          <TouchableOpacity
            style={[styles.checkBtn, isAnswered && styles.checkBtnDisabled]}
            onPress={() => {
              if (checkAnswer(answer)) setShowWarning(false);
            }}
            disabled={isAnswered}
          >
            <Text style={styles.checkTxt}>
              {isAnswered ? 'Sprawdzone' : 'Sprawdź'}
            </Text>
          </TouchableOpacity>
        </KeyboardAvoidingView>
      )}

      {feedback === 'correct' && (
        <Text style={styles.feedbackCorrect}>✔️ Poprawnie!</Text>
      )}
      {feedback === 'wrong' && (
        <Text style={styles.feedbackWrong}>
          ❌ Prawidłowo: {question.correct}
        </Text>
      )}
      {feedback === 'empty' && (
        <Text style={styles.feedbackWarning}>❗ Wpisz odpowiedź.</Text>
      )}
      {showWarning && (
        <Text style={styles.feedbackWarning}>
          ❗ Najpierw odpowiedz na pytanie.
        </Text>
      )}

      <TouchableOpacity
        style={styles.nextBtn}
        onPress={() => {
          if (!isAnswered) setShowWarning(true);
          else nextQuestion();
        }}
      >
        <Text style={styles.nextTxt}>Następne</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#2C2C2E',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    paddingTop: Platform.OS === 'android' ? 60 : 20,
  },
  backButton: {
    position: 'absolute',
    top: Platform.OS === 'android' ? 20 : 10,
    left: 20,
    zIndex: 1,
  },
  backArrow: {
    color: '#007AFF',
    fontSize: 16,
    fontWeight: '600',
  },
  modeLabel: {
    color: '#CCC',
    fontSize: 16,
    marginBottom: 8,
    fontStyle: 'italic',
  },
  prompt: {
    color: '#FFF',
    fontSize: 32,
    fontWeight: '700',
    marginBottom: 20,
    textAlign: 'center',
  },
  optionsWrapper: {
    width: '100%',
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  optionBtn: {
    backgroundColor: '#3b82f6',
    flexBasis: '30%',
    alignItems: 'center',
    paddingVertical: 12,
    marginVertical: 5,
    borderRadius: 8,
  },
  optionTxt: { color: '#FFF', fontSize: 16, fontWeight: '600' },
  optionCorrect: { backgroundColor: '#34C759' },
  optionWrong: { backgroundColor: '#FF3B30' },
  inputWrapper: { width: '85%', alignItems: 'center', marginBottom: 20 },
  input: {
    width: '100%',
    borderWidth: 2,
    borderColor: '#48484A',
    borderRadius: 12,
    padding: 16,
    fontSize: 20,
    color: '#FFF',
    backgroundColor: '#1C1C1E',
    marginBottom: 16,
    textAlign: 'center',
  },
  inputDisabled: { backgroundColor: '#48484A' },
  checkBtn: {
    backgroundColor: '#34C759',
    paddingVertical: 14,
    paddingHorizontal: 40,
    borderRadius: 12,
  },
  checkBtnDisabled: { backgroundColor: '#48484A' },
  checkTxt: { color: '#FFF', fontSize: 18, fontWeight: '700' },
  feedbackCorrect: { color: '#34C759', fontSize: 18, marginTop: 10 },
  feedbackWrong: { color: '#FF3B30', fontSize: 18, marginTop: 10 },
  feedbackWarning: { color: '#FF9500', fontSize: 18, marginTop: 10 },
  nextBtn: {
    marginTop: 20,
    backgroundColor: '#007AFF',
    paddingVertical: 14,
    paddingHorizontal: 40,
    borderRadius: 12,
  },
  nextTxt: { color: '#FFF', fontSize: 18, fontWeight: '700' },
});
